package uz.cosmeticsmod.mixin;

import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.cosmeticsmod.Cosmetic;
import uz.cosmeticsmod.CosmeticSlot;
import uz.cosmeticsmod.CosmeticsConfig;

/**
 * Mace uchun "skin": agar menyuda Mace Skin yoqilgan bo'lsa, mace'ning item modeli
 * o'rniga tanlangan skin (masalan Mjolnir) modeli ishlatiladi.
 */
@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

	@SuppressWarnings("unchecked")
	@Inject(method = "get(Lnet/minecraft/component/ComponentType;)Ljava/lang/Object;", at = @At("HEAD"), cancellable = true, require = 0)
	private <T> void cosmetics$maceSkin(ComponentType<? extends T> type, CallbackInfoReturnable<T> cir) {
		if (type != DataComponentTypes.ITEM_MODEL) return;
		ItemStack self = (ItemStack) (Object) this;
		if (!self.isOf(Items.MACE)) return;
		Cosmetic skin = CosmeticsConfig.get().equippedIn(CosmeticSlot.MACE);
		if (skin != null && skin.itemModel != null) {
			cir.setReturnValue((T) skin.itemModel);
		}
	}
}
