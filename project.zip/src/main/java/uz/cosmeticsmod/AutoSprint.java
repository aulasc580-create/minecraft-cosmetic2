package uz.cosmeticsmod;

import net.minecraft.client.MinecraftClient;

/** Auto Sprint: oldinga yurganda avtomatik yugurish. */
public final class AutoSprint {
	private AutoSprint() {}

	public static void tick(MinecraftClient mc) {
		if (!CosmeticsConfig.get().autoSprint || mc.player == null || mc.currentScreen != null) return;
		if (mc.options.forwardKey.isPressed() && !mc.options.sneakKey.isPressed()) {
			mc.options.sprintKey.setPressed(true);
		}
	}
}
