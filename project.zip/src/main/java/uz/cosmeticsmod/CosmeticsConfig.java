package uz.cosmeticsmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Sozlamalar: .minecraft/config/cosmetics.json */
public final class CosmeticsConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static CosmeticsConfig instance = new CosmeticsConfig();

	/** slot kaliti -> cosmetic id (masalan "back" -> "backpack") */
	public Map<String, String> equipped = new LinkedHashMap<>();
	/** Hamma cosmetic'lar o'lchamini kattalashtirish/kichraytirish (1.0 = odatiy) */
	public float sizeMultiplier = 1.0f;
	/** O'z skin fayli (config/cosmetics_skins/ ichida), bo'sh = original skin */
	public String skinFile = "";
	/** true = ingichka (Alex) qo'llar */
	public boolean skinSlim = false;
	/** Menyu rang mavzusi: violet / pink / blue */
	public String theme = "violet";
	/** Vizual effektlar */
	public boolean jumpCircle = false;
	public boolean trail = false;
	/** Effekt rangi: theme / violet / pink / blue / rainbow */
	public String effectColor = "theme";
	/** Watermark (yuqori o'rtada) va uning bo'laklari */
	public boolean watermark = false;
	public boolean wmName = true, wmPing = true, wmFps = true, wmTime = false;
	/** Cho'zilgan ekran (aspect ratio) */
	public boolean aspectRatio = false;
	public float aspectValue = 4f / 3f;
	/** Effekt sozlamalari */
	public String jumpColor = "theme";
	public String trailColor = "theme";
	public float jumpScale = 1.0f;
	public float trailWidth = 1.0f;
	/** Har bir cosmetic uchun balandlik siljishi: id -> qiymat (kiyimlar: piksel, petlar: blok) */
	public Map<String, Float> heights = new LinkedHashMap<>();

	// ---- Visuals modullari ----
	public boolean fullbright, viewmodel, targetEsp, targetHud, potionsHud, moduleList, durabilityHud,
			freelook, autoSprint, clientSound;
	public boolean menuBlur = true, liquidGlass = false, roundedMenu = true;
	public float fullbrightGamma = 12f;
	public float vmX = 0f, vmY = 0f, vmZ = 0f, vmScale = 1f;
	public String espColor = "theme";
	public int espStyle = 2; // 0 halqa, 1 quti, 2 ikkalasi
	public int targetPos = 0, potionsPos = 0, durabilityPos = 0, moduleListPos = 0;
	public float freelookSens = 1f;
	public boolean freelookThird = true;
	public boolean soundUi = true, soundToggle = true;
	public int soundHit = 0; // 0 o'chiq, 1 click, 2 orb
	public float menuRadius = 20f;
	public float glassAlpha = 0.55f;
	/** Har bir cosmetic uchun alohida o'lcham: id -> koeffitsient (1.0 = odatiy) */
	public Map<String, Float> sizes = new LinkedHashMap<>();

	public static CosmeticsConfig get() {
		return instance;
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("cosmetics.json");
	}

	public static void load() {
		Path p = path();
		if (Files.exists(p)) {
			try (Reader r = Files.newBufferedReader(p)) {
				CosmeticsConfig loaded = GSON.fromJson(r, CosmeticsConfig.class);
				if (loaded != null) {
					if (loaded.equipped == null) loaded.equipped = new LinkedHashMap<>();
					if (loaded.sizes == null) loaded.sizes = new LinkedHashMap<>();
					if (loaded.heights == null) loaded.heights = new LinkedHashMap<>();
					if (loaded.jumpColor == null) loaded.jumpColor = "theme";
					if (loaded.trailColor == null) loaded.trailColor = "theme";
					if (loaded.aspectValue < 0.5f) loaded.aspectValue = 4f / 3f;
					if (loaded.espColor == null) loaded.espColor = "theme";
					instance = loaded;
					return;
				}
			} catch (Exception e) {
				CosmeticsMod.LOGGER.warn("Config o'qilmadi, standart ishlatiladi", e);
			}
		}
		// Birinchi ishga tushirish: backpack avtomatik kiyiladi
		instance = new CosmeticsConfig();
		instance.equipped.put(CosmeticSlot.BACK.key, "backpack");
		save();
	}

	public static void save() {
		try (Writer w = Files.newBufferedWriter(path())) {
			GSON.toJson(instance, w);
		} catch (Exception e) {
			CosmeticsMod.LOGGER.warn("Config saqlanmadi", e);
		}
	}

	public float sizeOf(Cosmetic c) {
		if (sizes == null) sizes = new LinkedHashMap<>();
		Float v = sizes.get(c.id);
		return v == null ? 1.0f : v;
	}

	public float heightOf(Cosmetic c) {
		if (heights == null) heights = new LinkedHashMap<>();
		Float v = heights.get(c.id);
		return v == null ? 0f : v;
	}

	public void setHeight(Cosmetic c, float v) {
		if (heights == null) heights = new LinkedHashMap<>();
		heights.put(c.id, v);
	}

	public void setSize(Cosmetic c, float v) {
		if (sizes == null) sizes = new LinkedHashMap<>();
		sizes.put(c.id, v);
	}

	public Cosmetic equippedIn(CosmeticSlot slot) {
		return CosmeticRegistry.get(equipped.get(slot.key));
	}

	public void equip(CosmeticSlot slot, Cosmetic c) {
		if (c == null) equipped.remove(slot.key);
		else equipped.put(slot.key, c.id);
	}

	public List<Cosmetic> allEquipped() {
		List<Cosmetic> out = new ArrayList<>();
		for (CosmeticSlot s : CosmeticSlot.values()) {
			Cosmetic c = equippedIn(s);
			if (c != null) out.add(c);
		}
		return out;
	}
}
