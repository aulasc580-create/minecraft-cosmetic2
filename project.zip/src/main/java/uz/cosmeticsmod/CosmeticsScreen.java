package uz.cosmeticsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import java.util.ArrayList;
import java.util.List;

/**
 * Zamonaviy Cosmetics menyusi (K tugmasi).
 * Chapda kategoriyalar, o'ngda tanlanadigan kartochkalar, pastda tanlangan narsa uchun o'lcham slayderi.
 * O'ng tugma: keyingi variant. Sichqoncha g'ildiragi: ro'yxatni aylantirish.
 */
public class CosmeticsScreen extends Screen {
	private static final int W = 480;
	private static final int H = 316;
	private static final int HEADER_H = 40;
	private static final int SIDE_W = 112;
	private static final int PAD = 14;
	private static final int TAB_H = 26;
	private static final int CARD_H = 30;
	private static final int CARD_GAP = 6;
	private static final int SIZE_PANEL_H = 62;

	private static final float SIZE_MIN = 0.3f, SIZE_MAX = 3.0f;

	// Neon violet palitra
	private static final int COL_DIM = 0xB0000000;
	private int COL_BORDER;
	private int COL_PANEL;
	private int COL_SIDE;
	private int COL_CARD;
	private int COL_CARD_HOVER;
	private int COL_ACCENT;
	private int COL_ACCENT_SOFT;
	private static final int COL_TEXT = 0xFFF4F0FF;
	private int COL_MUTED;
	private static final int COL_GOOD = 0xFF7CF0B0;

	private final Screen parent;
	private final List<CosmeticSlot> slots = new ArrayList<>();
	private List<String> skinFiles = new ArrayList<>();
	private int selected = 0;
	private int scroll = 0;
	private boolean dragging = false;
	private int px, py;

	public CosmeticsScreen(Screen parent) {
		super(Text.translatable("screen.cosmetics.title"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		slots.clear();
		for (CosmeticSlot slot : CosmeticSlot.values()) {
			if (!CosmeticRegistry.forSlot(slot).isEmpty()) slots.add(slot);
		}
		skinFiles = CustomSkin.list();
		if (selected > slots.size() + 2) selected = 0;
		px = (this.width - W) / 2;
		py = Math.max(4, (this.height - H) / 2);
	}

	// ---- joylashuv ----
	private int sideTabY(int i) { return py + HEADER_H + 10 + i * (TAB_H + 3); }
	private int contentX() { return px + SIDE_W + 12; }
	private int contentW() { return W - SIDE_W - 12 - PAD; }
	private int listY() { return py + HEADER_H + 10; }
	private int listH() { return H - HEADER_H - 10 - SIZE_PANEL_H - 22; }
	private int sizeY() { return py + H - PAD - SIZE_PANEL_H; }
	private int closeX() { return px + W - PAD - 22; }
	private int closeY() { return py + 9; }
	private int trackX() { return contentX() + 14; }
	private int trackW() { return contentW() - 14 - 110; }
	private int trackY() { return sizeY() + 36; }
	private int resetX() { return contentX() + contentW() - 14 - 44; }

	private boolean onSlotTab() { return selected < slots.size(); }
	private boolean onSkinTab() { return selected == slots.size(); }
	private boolean onVisTab() { return selected == slots.size() + 1; }
	private boolean onThemeTab() { return selected == slots.size() + 2; }

	private CosmeticSlot currentSlot() {
		return onSlotTab() ? slots.get(selected) : null;
	}

	private int optionCount() {
		if (onSkinTab()) return skinFiles.size() + 1;
		if (onVisTab()) return 2;
		if (onThemeTab()) return Theme.ALL.length;
		return options().size();
	}

	private static final String[] FX_IDS = {"theme", "violet", "pink", "blue", "rainbow"};
	private static final String[] FX_NAMES = {"Menu theme", "Violet", "Pink", "Dark Blue", "Rainbow"};

	private static int fxIndex() {
		String c = CosmeticsConfig.get().effectColor;
		for (int i = 0; i < FX_IDS.length; i++) if (FX_IDS[i].equals(c)) return i;
		return 0;
	}

	private void applyTheme() {
		Theme t = Theme.current();
		COL_BORDER = t.border; COL_PANEL = t.panel; COL_SIDE = t.side; COL_CARD = t.card;
		COL_CARD_HOVER = t.cardHover; COL_ACCENT = t.accent; COL_ACCENT_SOFT = t.accentSoft; COL_MUTED = t.muted;
	}

	private int skinBtnY() { return sizeY() + 32; }

	private List<Cosmetic> options() {
		List<Cosmetic> o = new ArrayList<>();
		CosmeticSlot s = currentSlot();
		if (s == null) return o;
		o.add(null); // "None"
		o.addAll(CosmeticRegistry.forSlot(s));
		return o;
	}

	private int cardY(int i) { return listY() + i * (CARD_H + CARD_GAP) - scroll; }

	private int maxScroll() {
		int total = optionCount() * (CARD_H + CARD_GAP) - CARD_GAP;
		return Math.max(0, total - listH());
	}

	private static boolean inside(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	private Cosmetic equippedNow() {
		CosmeticSlot s = currentSlot();
		return s == null ? null : CosmeticsConfig.get().equippedIn(s);
	}

	// ---- chizish ----
	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
		applyTheme();
		ctx.fill(0, 0, this.width, this.height, COL_DIM);

		// Panel (yumaloq burchak o'rnini bo'sh qoldiramiz)
		roundRect(ctx, px - 1, py - 1, W + 2, H + 2, COL_BORDER);
		roundRect(ctx, px, py, W, H, COL_PANEL);
		// Yon panel
		ctx.fill(px, py + HEADER_H, px + SIDE_W, py + H - 3, COL_SIDE);
		ctx.fill(px + SIDE_W, py + HEADER_H, px + SIDE_W + 1, py + H - 3, COL_BORDER);
		// Sarlavha
		ctx.fill(px + 3, py, px + W - 3, py + 2, COL_ACCENT);
		ctx.fill(px, py + HEADER_H - 1, px + W, py + HEADER_H, COL_BORDER);
		drawText(ctx, this.title, px + PAD, py + 12, 1.6f, COL_TEXT, false);
		drawText(ctx, Text.literal("by Rediska4"), px + PAD + 108, py + 17, 0.9f, COL_ACCENT, false);

		// Yopish tugmasi
		boolean ch = inside(mouseX, mouseY, closeX(), closeY(), 22, 22);
		roundRect(ctx, closeX(), closeY(), 22, 22, ch ? COL_ACCENT : COL_CARD);
		drawText(ctx, Text.literal("x"), closeX() + 11, closeY() + 6, 1.2f, COL_TEXT, true);

		// Kategoriyalar
		for (int i = 0; i < slots.size() + 3; i++) {
			CosmeticSlot s = i < slots.size() ? slots.get(i) : null;
			int y = sideTabY(i);
			boolean sel = i == selected;
			boolean hov = inside(mouseX, mouseY, px + 8, y, SIDE_W - 16, TAB_H);
			if (sel) {
				roundRect(ctx, px + 8, y, SIDE_W - 16, TAB_H, COL_ACCENT_SOFT);
				ctx.fill(px + 8, y + 4, px + 11, y + TAB_H - 4, COL_ACCENT);
			} else if (hov) {
				roundRect(ctx, px + 8, y, SIDE_W - 16, TAB_H, COL_CARD);
			}
			Text tabLabel = s != null ? s.displayName() : (i == slots.size() ? Text.literal("Skin") : (i == slots.size() + 1 ? Text.literal("Visuals") : Text.literal("Theme")));
			drawText(ctx, tabLabel, px + 20, y + 8, 1.05f, sel ? COL_TEXT : COL_MUTED, false);
			boolean on = s != null ? CosmeticsConfig.get().equippedIn(s) != null : (i == slots.size() ? !CosmeticsConfig.get().skinFile.isEmpty() : (i == slots.size() + 1 && (CosmeticsConfig.get().jumpCircle || CosmeticsConfig.get().trail)));
			if (on) {
				ctx.fill(px + SIDE_W - 22, y + 10, px + SIDE_W - 16, y + 16, COL_GOOD);
			}
		}

		// Kartochkalar (kesib chizamiz, shunda aylantirganda panel tashqarisiga chiqmaydi)
		Cosmetic eq = equippedNow();
		List<Cosmetic> opts = options();
		int count = optionCount();
		ctx.enableScissor(contentX() - 2, listY(), contentX() + contentW() + 2, listY() + listH());
		for (int i = 0; i < count; i++) {
			int y = cardY(i);
			if (y + CARD_H < listY() || y > listY() + listH()) continue;
			Cosmetic c = onSlotTab() ? opts.get(i) : null;
			String file = onSkinTab() && i > 0 ? skinFiles.get(i - 1) : null;
			boolean active;
			Text name;
			if (onSkinTab()) {
				active = file == null ? CosmeticsConfig.get().skinFile.isEmpty() : file.equals(CosmeticsConfig.get().skinFile);
				name = file == null ? Text.literal("Original skin") : Text.literal(file);
			} else if (onVisTab()) {
				active = i == 0 ? CosmeticsConfig.get().jumpCircle : CosmeticsConfig.get().trail;
				name = Text.literal(i == 0 ? "Jump Circle" : "Trail");
			} else if (onThemeTab()) {
				active = Theme.ALL[i].id.equals(Theme.current().id);
				name = Text.literal(Theme.ALL[i].name);
			} else {
				active = c == eq;
				name = c == null ? Text.translatable("cosmetics.none") : c.displayName();
			}
			boolean hov = inside(mouseX, mouseY, contentX(), y, contentW(), CARD_H)
					&& mouseY >= listY() && mouseY < listY() + listH();
			if (active) roundRect(ctx, contentX() - 1, y - 1, contentW() + 2, CARD_H + 2, COL_ACCENT);
			roundRect(ctx, contentX(), y, contentW(), CARD_H, hov ? COL_CARD_HOVER : COL_CARD);
			boolean none = onSlotTab() && c == null;
			drawText(ctx, name, contentX() + 14, y + 10, 1.15f, none ? COL_MUTED : COL_TEXT, false);
			if (onVisTab()) {
				drawText(ctx, Text.literal(active ? "ON" : "OFF"), contentX() + contentW() - 14, y + 11, 0.9f, active ? COL_GOOD : COL_MUTED, false, true);
			} else if (active) {
				drawText(ctx, Text.literal(none ? "ON" : (onThemeTab() ? "ACTIVE" : "EQUIPPED")), contentX() + contentW() - 14, y + 11, 0.9f, COL_GOOD, false, true);
			}
		}
		ctx.disableScissor();

		// Aylantirish chizig'i
		int ms = maxScroll();
		if (ms > 0) {
			int trackH = listH();
			int barH = Math.max(16, trackH * trackH / (trackH + ms));
			int barY = listY() + (int) ((trackH - barH) * (scroll / (float) ms));
			ctx.fill(contentX() + contentW() + 4, barY, contentX() + contentW() + 6, barY + barH, COL_ACCENT);
		}

		// O'lcham paneli
		int sy = sizeY();
		roundRect(ctx, contentX(), sy, contentW(), SIZE_PANEL_H, COL_CARD);
		if (onSkinTab()) {
			drawText(ctx, Text.literal("Drop a 64x64 .png skin onto this window"), contentX() + 14, sy + 9, 1.0f, COL_TEXT, false);
			boolean oh = inside(mouseX, mouseY, contentX() + 14, skinBtnY(), 110, 20);
			roundRect(ctx, contentX() + 14, skinBtnY(), 110, 20, oh ? COL_ACCENT : COL_ACCENT_SOFT);
			drawText(ctx, Text.literal("Open skins folder"), contentX() + 14 + 55, skinBtnY() + 6, 0.95f, COL_TEXT, true);
			boolean ah = inside(mouseX, mouseY, contentX() + 134, skinBtnY(), 120, 20);
			roundRect(ctx, contentX() + 134, skinBtnY(), 120, 20, ah ? COL_ACCENT : COL_ACCENT_SOFT);
			drawText(ctx, Text.literal("Arms: " + (CosmeticsConfig.get().skinSlim ? "Slim" : "Classic")),
					contentX() + 134 + 60, skinBtnY() + 6, 0.95f, COL_TEXT, true);
		} else if (onVisTab()) {
			drawText(ctx, Text.literal("Effect color"), contentX() + 14, sy + 9, 1.0f, COL_TEXT, false);
			boolean fh = inside(mouseX, mouseY, contentX() + 14, skinBtnY(), 150, 20);
			roundRect(ctx, contentX() + 14, skinBtnY(), 150, 20, fh ? COL_ACCENT : COL_ACCENT_SOFT);
			drawText(ctx, Text.literal("Color: " + FX_NAMES[fxIndex()] + "  >"), contentX() + 14 + 75, skinBtnY() + 6, 0.95f, COL_TEXT, true);
		} else if (onThemeTab()) {
			drawText(ctx, Text.literal("Pick the color of this menu"), contentX() + contentW() / 2, sy + 26, 1.0f, COL_MUTED, true);
		} else if (eq != null && !eq.isItemSkin()) {
			float v = CosmeticsConfig.get().sizeOf(eq);
			drawText(ctx, Text.literal("Size"), contentX() + 14, sy + 10, 1.1f, COL_MUTED, false);
			drawText(ctx, eq.displayName(), contentX() + 56, sy + 10, 1.1f, COL_TEXT, false);
			drawText(ctx, Text.literal(Math.round(v * 100) + "%"),
					contentX() + contentW() - 14, sy + 10, 1.1f, COL_ACCENT, false, true);
			// slayder
			int tx = trackX(), ty = trackY(), tw = trackW();
			roundRect(ctx, tx, ty - 2, tw, 6, COL_SIDE);
			float f = (v - SIZE_MIN) / (SIZE_MAX - SIZE_MIN);
			int fx = tx + Math.round(tw * f);
			ctx.fill(tx + 1, ty - 1, Math.max(tx + 1, fx), ty + 3, COL_ACCENT);
			boolean kh = dragging || inside(mouseX, mouseY, fx - 6, ty - 8, 12, 18);
			roundRect(ctx, fx - 5, ty - 7, 10, 14, kh ? COL_TEXT : COL_ACCENT);
			// tiklash tugmasi
			boolean rh = inside(mouseX, mouseY, resetX(), ty - 9, 44, 18);
			roundRect(ctx, resetX(), ty - 9, 44, 18, rh ? COL_ACCENT : COL_ACCENT_SOFT);
			drawText(ctx, Text.literal("Reset"), resetX() + 22, ty - 4, 0.9f, COL_TEXT, true);
		} else {
			String hint = eq == null ? "Select an item to change its size" : "This item has no size option";
			drawText(ctx, Text.literal(hint), contentX() + contentW() / 2, sy + 26, 1.0f, COL_MUTED, true);
		}

		// Pastki yordam
		drawText(ctx, Text.literal("Right click: next item   |   Scroll: list   |   Esc: close"),
				px + W / 2, py + H - 11, 0.8f, COL_MUTED, true);
	}

	/** Burchaklari 1 piksel kesilgan to'rtburchak (zamonaviy yumaloq ko'rinish uchun). */
	private static void roundRect(DrawContext ctx, int x, int y, int w, int h, int color) {
		ctx.fill(x + 1, y, x + w - 1, y + h, color);
		ctx.fill(x, y + 1, x + w, y + h - 1, color);
	}

	/** Kattalashtirilgan matn. (x,y) = chap-yuqori; centered bo'lsa markaz; rightAligned bo'lsa o'ng chet. */
	private void drawText(DrawContext ctx, Text text, int x, int y, float scale, int color, boolean centered) {
		drawText(ctx, text, x, y, scale, color, centered, false);
	}

	private void drawText(DrawContext ctx, Text text, int x, int y, float scale, int color, boolean centered, boolean right) {
		float w = this.textRenderer.getWidth(text) * scale;
		float drawX = x;
		if (centered) drawX = x - w / 2f;
		else if (right) drawX = x - w;
		ctx.getMatrices().push();
		ctx.getMatrices().translate(drawX, (float) y, 0f);
		ctx.getMatrices().scale(scale, scale, 1f);
		ctx.drawTextWithShadow(this.textRenderer, text, 0, 0, color);
		ctx.getMatrices().pop();
	}

	// ---- boshqaruv ----
	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (button == 0) {
			if (inside(mx, my, closeX(), closeY(), 22, 22)) {
				this.close();
				return true;
			}
			// kategoriyalar
			for (int i = 0; i < slots.size() + 3; i++) {
				if (inside(mx, my, px + 8, sideTabY(i), SIDE_W - 16, TAB_H)) {
					selected = i;
					scroll = 0;
					skinFiles = CustomSkin.list();
					return true;
				}
			}
			// kartochkalar
			List<Cosmetic> opts = options();
			if (my >= listY() && my < listY() + listH()) {
				for (int i = 0; i < optionCount(); i++) {
					if (inside(mx, my, contentX(), cardY(i), contentW(), CARD_H)) {
						if (onSkinTab()) {
							CosmeticsConfig.get().skinFile = i == 0 ? "" : skinFiles.get(i - 1);
							CustomSkin.markDirty();
						} else if (onVisTab()) {
							if (i == 0) CosmeticsConfig.get().jumpCircle = !CosmeticsConfig.get().jumpCircle;
							else CosmeticsConfig.get().trail = !CosmeticsConfig.get().trail;
						} else if (onThemeTab()) {
							CosmeticsConfig.get().theme = Theme.ALL[i].id;
						} else {
							CosmeticsConfig.get().equip(currentSlot(), opts.get(i));
						}
						CosmeticsConfig.save();
						return true;
					}
				}
			}
			if (onVisTab() && inside(mx, my, contentX() + 14, skinBtnY(), 150, 20)) {
				CosmeticsConfig.get().effectColor = FX_IDS[(fxIndex() + 1) % FX_IDS.length];
				CosmeticsConfig.save();
				return true;
			}
			if (onSkinTab()) {
				if (inside(mx, my, contentX() + 14, skinBtnY(), 110, 20)) {
					try { Util.getOperatingSystem().open(CustomSkin.dir().toFile()); } catch (Exception ignored) {}
					return true;
				}
				if (inside(mx, my, contentX() + 134, skinBtnY(), 120, 20)) {
					CosmeticsConfig.get().skinSlim = !CosmeticsConfig.get().skinSlim;
					CosmeticsConfig.save();
					return true;
				}
			}
			// o'lcham slayderi / tiklash
			Cosmetic eq = equippedNow();
			if (eq != null && !eq.isItemSkin()) {
				if (inside(mx, my, resetX(), trackY() - 9, 44, 18)) {
					CosmeticsConfig.get().setSize(eq, 1.0f);
					CosmeticsConfig.save();
					return true;
				}
				if (inside(mx, my, trackX() - 8, trackY() - 10, trackW() + 16, 20)) {
					dragging = true;
					setFromMouse(mx, eq);
					return true;
				}
			}
		} else if (button == 1) {
			if (currentSlot() != null && inside(mx, my, px, py + HEADER_H, W, H - HEADER_H)) {
				cycle(currentSlot(), 1);
				return true;
			}
		}
		return super.mouseClicked(mx, my, button);
	}

	private void setFromMouse(double mx, Cosmetic eq) {
		float f = (float) ((mx - trackX()) / trackW());
		f = Math.max(0f, Math.min(1f, f));
		float v = SIZE_MIN + f * (SIZE_MAX - SIZE_MIN);
		v = Math.round(v * 20f) / 20f; // 5% qadam
		CosmeticsConfig.get().setSize(eq, Math.max(SIZE_MIN, Math.min(SIZE_MAX, v)));
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (dragging && button == 0) {
			Cosmetic eq = equippedNow();
			if (eq != null) setFromMouse(mx, eq);
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		if (dragging) {
			dragging = false;
			CosmeticsConfig.save();
			return true;
		}
		return super.mouseReleased(mx, my, button);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
		if (inside(mx, my, contentX(), listY(), contentW(), listH())) {
			scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) (vertical * 18)));
			return true;
		}
		return super.mouseScrolled(mx, my, horizontal, vertical);
	}

	private static void cycle(CosmeticSlot slot, int dir) {
		List<Cosmetic> options = new ArrayList<>();
		options.add(null); // "None"
		options.addAll(CosmeticRegistry.forSlot(slot));
		Cosmetic current = CosmeticsConfig.get().equippedIn(slot);
		int next = (options.indexOf(current) + dir + options.size()) % options.size();
		CosmeticsConfig.get().equip(slot, options.get(next));
		CosmeticsConfig.save();
	}

	/** PNG faylni oynaga tashlash: skinlar papkasiga ko'chiriladi va darhol tanlanadi. */
	@Override
	public void onFilesDropped(List<Path> paths) {
		for (Path p : paths) {
			String n = p.getFileName().toString();
			if (!n.toLowerCase(java.util.Locale.ROOT).endsWith(".png")) continue;
			try {
				Files.copy(p, CustomSkin.dir().resolve(n), StandardCopyOption.REPLACE_EXISTING);
				CosmeticsConfig.get().skinFile = n;
				CustomSkin.markDirty();
				CosmeticsConfig.save();
				skinFiles = CustomSkin.list();
				selected = slots.size();
				scroll = 0;
			} catch (Exception e) {
				CosmeticsMod.LOGGER.warn("Skin ko'chirilmadi", e);
			}
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		CosmeticsConfig.save();
		this.client.setScreen(parent);
	}
}
