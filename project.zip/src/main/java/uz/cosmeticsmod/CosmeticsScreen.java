package uz.cosmeticsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * Cosmetics menyusi (K tugmasi). Chapda bo'limlar, o'ngda kartochkalar.
 * Chap tugma: tanlash / yoqish-o'chirish. O'ng tugma: shu narsaning alohida sozlamalar oynasi.
 */
public class CosmeticsScreen extends Screen {
	private static final int W = 480;
	private static final int H = 316;
	private static final int HEADER_H = 44;
	private static final int SIDE_W = 116;
	private static final int PAD = 14;
	private static final int TAB_H = 26;
	private static final int CARD_H = 32;
	private static final int CARD_GAP = 6;

	private static final int COL_DIM = 0xB0000000;
	private static final int COL_TEXT = 0xFFF4F0FF;
	private static final int COL_GOOD = 0xFF7CF0B0;

	private static final String[] VIS_NAMES = {"Jump Circle", "Trail", "Watermark", "Stretched Screen"};

	private Theme th = Theme.ALL[0];
	private final Screen parent;
	private final List<CosmeticSlot> slots = new ArrayList<>();
	private List<String> skinFiles = new ArrayList<>();
	private int selected = 0;
	private int scroll = 0;
	private int px, py;

	public CosmeticsScreen(Screen parent) {
		super(Text.translatable("screen.cosmetics.title"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		slots.clear();
		for (CosmeticSlot slot : CosmeticSlot.values()) {
			if (!CosmeticRegistry.forSlot(slot).isEmpty()) slots.add(slot);
		}
		skinFiles = CustomSkin.list();
		if (selected > slots.size() + 2) selected = 0;
		px = (this.width - W) / 2;
		py = Math.max(4, (this.height - H) / 2);
	}

	// ---- bo'limlar ----
	private boolean onSlotTab() { return selected < slots.size(); }
	private boolean onSkinTab() { return selected == slots.size(); }
	private boolean onVisTab() { return selected == slots.size() + 1; }
	private boolean onThemeTab() { return selected == slots.size() + 2; }
	private CosmeticSlot currentSlot() { return onSlotTab() ? slots.get(selected) : null; }

	private List<Cosmetic> options() {
		List<Cosmetic> o = new ArrayList<>();
		CosmeticSlot s = currentSlot();
		if (s == null) return o;
		o.add(null); // "None"
		o.addAll(CosmeticRegistry.forSlot(s));
		return o;
	}

	private int optionCount() {
		if (onSkinTab()) return skinFiles.size() + 1;
		if (onVisTab()) return VIS_NAMES.length;
		if (onThemeTab()) return Theme.ALL.length;
		return options().size();
	}

	private static boolean visGet(int i) {
		CosmeticsConfig c = CosmeticsConfig.get();
		return switch (i) {
			case 0 -> c.jumpCircle;
			case 1 -> c.trail;
			case 2 -> c.watermark;
			default -> c.aspectRatio;
		};
	}

	private static void visToggle(int i) {
		CosmeticsConfig c = CosmeticsConfig.get();
		switch (i) {
			case 0 -> c.jumpCircle = !c.jumpCircle;
			case 1 -> c.trail = !c.trail;
			case 2 -> c.watermark = !c.watermark;
			default -> c.aspectRatio = !c.aspectRatio;
		}
	}

	// ---- joylashuv ----
	private int sideX() { return px + 8; }
	private int sideW() { return SIDE_W - 8; }
	private int sideY() { return py + HEADER_H; }
	private int sideH() { return H - HEADER_H - 8; }
	private int tabX() { return sideX() + 6; }
	private int tabW() { return sideW() - 12; }
	private int tabY(int i) { return sideY() + 8 + i * (TAB_H + 3); }
	private int contentX() { return px + SIDE_W + 10; }
	private int contentW() { return W - SIDE_W - 10 - PAD; }
	private int listY() { return py + HEADER_H + 6; }
	private int listH() { return H - HEADER_H - 6 - 34; }
	private int closeX() { return px + W - PAD - 22; }
	private int closeY() { return py + 11; }
	private int cardY(int i) { return listY() + i * (CARD_H + CARD_GAP) - scroll; }

	private int maxScroll() {
		int total = optionCount() * (CARD_H + CARD_GAP) - CARD_GAP;
		return Math.max(0, total - listH());
	}

	private Cosmetic equippedNow() {
		CosmeticSlot s = currentSlot();
		return s == null ? null : CosmeticsConfig.get().equippedIn(s);
	}

	// ---- chizish ----
	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
		th = Theme.current();
		ctx.fill(0, 0, this.width, this.height, COL_DIM);

		// Panel
		Gfx.roundRect(ctx, px - 1, py - 1, W + 2, H + 2, 21, th.border);
		Gfx.roundRect(ctx, px, py, W, H, 20, th.panel);
		Gfx.text(ctx, this.textRenderer, this.title, px + 22, py + 14, 1.6f, COL_TEXT, 0);
		Gfx.text(ctx, this.textRenderer, Text.literal("by Rediska4"), px + 22 + 110, py + 19, 0.9f, th.accent, 0);

		// Yopish tugmasi (aylana)
		boolean ch = Gfx.inside(mouseX, mouseY, closeX(), closeY(), 22, 22);
		Gfx.roundRect(ctx, closeX(), closeY(), 22, 22, 11, ch ? th.accent : th.card);
		Gfx.text(ctx, this.textRenderer, Text.literal("x"), closeX() + 11, closeY() + 7, 1.2f, COL_TEXT, 1);

		// Yon panel
		Gfx.roundRect(ctx, sideX(), sideY(), sideW(), sideH(), 14, th.side);
		for (int i = 0; i < slots.size() + 3; i++) {
			CosmeticSlot s = i < slots.size() ? slots.get(i) : null;
			int y = tabY(i);
			boolean sel = i == selected;
			boolean hov = Gfx.inside(mouseX, mouseY, tabX(), y, tabW(), TAB_H);
			if (sel) Gfx.roundRect(ctx, tabX(), y, tabW(), TAB_H, 10, th.accentSoft);
			else if (hov) Gfx.roundRect(ctx, tabX(), y, tabW(), TAB_H, 10, th.card);
			Text label = s != null ? s.displayName()
					: (i == slots.size() ? Text.literal("Skin") : (i == slots.size() + 1 ? Text.literal("Visuals") : Text.literal("Theme")));
			Gfx.text(ctx, this.textRenderer, label, tabX() + 12, y + 8, 1.05f, sel ? COL_TEXT : th.muted, 0);
			CosmeticsConfig cfg = CosmeticsConfig.get();
			boolean on = s != null ? cfg.equippedIn(s) != null
					: (i == slots.size() ? !cfg.skinFile.isEmpty()
					: (i == slots.size() + 1 && (cfg.jumpCircle || cfg.trail || cfg.watermark || cfg.aspectRatio)));
			if (on) Gfx.roundRect(ctx, tabX() + tabW() - 14, y + 10, 6, 6, 3, COL_GOOD);
		}

		// Kartochkalar
		Cosmetic eq = equippedNow();
		List<Cosmetic> opts = options();
		int count = optionCount();
		ctx.enableScissor(contentX() - 2, listY(), contentX() + contentW() + 2, listY() + listH());
		for (int i = 0; i < count; i++) {
			int y = cardY(i);
			if (y + CARD_H < listY() || y > listY() + listH()) continue;
			Cosmetic c = onSlotTab() ? opts.get(i) : null;
			boolean active;
			Text name;
			if (onSkinTab()) {
				String file = i > 0 ? skinFiles.get(i - 1) : null;
				active = file == null ? CosmeticsConfig.get().skinFile.isEmpty() : file.equals(CosmeticsConfig.get().skinFile);
				name = file == null ? Text.literal("Original skin") : Text.literal(file);
			} else if (onVisTab()) {
				active = visGet(i);
				name = Text.literal(VIS_NAMES[i]);
			} else if (onThemeTab()) {
				active = Theme.ALL[i].id.equals(th.id);
				name = Text.literal(Theme.ALL[i].name);
			} else {
				active = c == eq;
				name = c == null ? Text.translatable("cosmetics.none") : c.displayName();
			}
			boolean hov = Gfx.inside(mouseX, mouseY, contentX(), y, contentW(), CARD_H)
					&& mouseY >= listY() && mouseY < listY() + listH();
			if (active) Gfx.roundRect(ctx, contentX() - 1, y - 1, contentW() + 2, CARD_H + 2, 15, th.accent);
			Gfx.roundRect(ctx, contentX(), y, contentW(), CARD_H, 14, hov ? th.cardHover : th.card);
			boolean none = onSlotTab() && c == null;
			Gfx.text(ctx, this.textRenderer, name, contentX() + 16, y + 11, 1.15f, none ? th.muted : COL_TEXT, 0);
			if (onVisTab()) {
				Gfx.text(ctx, this.textRenderer, Text.literal(active ? "ON" : "OFF"), contentX() + contentW() - 16, y + 12, 0.9f,
						active ? COL_GOOD : th.muted, 2);
			} else if (active) {
				Gfx.text(ctx, this.textRenderer, Text.literal(none ? "ON" : (onThemeTab() ? "ACTIVE" : "EQUIPPED")),
						contentX() + contentW() - 16, y + 12, 0.9f, COL_GOOD, 2);
			}
		}
		ctx.disableScissor();

		// Aylantirish chizig'i
		int ms = maxScroll();
		if (ms > 0) {
			int trackH = listH();
			int barH = Math.max(16, trackH * trackH / (trackH + ms));
			int barY = listY() + (int) ((trackH - barH) * (scroll / (float) ms));
			Gfx.roundRect(ctx, contentX() + contentW() + 4, barY, 3, barH, 1, th.accent);
		}

		// Pastki yordam
		String hint = onSkinTab() ? "Drop a 64x64 .png onto this window   |   Right click: skin settings"
				: (onThemeTab() ? "Click a color to change the menu theme"
				: "Click: select   |   Right click: settings   |   Scroll: list");
		Gfx.text(ctx, this.textRenderer, Text.literal(hint), px + W / 2, py + H - 22, 0.85f, th.muted, 1);
	}

	// ---- boshqaruv ----
	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (button == 0) {
			if (Gfx.inside(mx, my, closeX(), closeY(), 22, 22)) {
				this.close();
				return true;
			}
			for (int i = 0; i < slots.size() + 3; i++) {
				if (Gfx.inside(mx, my, tabX(), tabY(i), tabW(), TAB_H)) {
					selected = i;
					scroll = 0;
					skinFiles = CustomSkin.list();
					return true;
				}
			}
			int idx = cardAt(mx, my);
			if (idx >= 0) {
				List<Cosmetic> opts = options();
				if (onSkinTab()) {
					CosmeticsConfig.get().skinFile = idx == 0 ? "" : skinFiles.get(idx - 1);
					CustomSkin.markDirty();
				} else if (onVisTab()) {
					visToggle(idx);
				} else if (onThemeTab()) {
					CosmeticsConfig.get().theme = Theme.ALL[idx].id;
				} else {
					CosmeticsConfig.get().equip(currentSlot(), opts.get(idx));
				}
				CosmeticsConfig.save();
				return true;
			}
		} else if (button == 1) {
			int idx = cardAt(mx, my);
			if (idx >= 0 && this.client != null) {
				Screen next = null;
				if (onSkinTab()) {
					next = SettingsScreen.forSkin(this);
				} else if (onVisTab()) {
					next = SettingsScreen.forVisual(this, idx);
				} else if (onSlotTab()) {
					Cosmetic c = options().get(idx);
					if (c != null && !c.isItemSkin()) next = SettingsScreen.forCosmetic(this, c);
				}
				if (next != null) {
					this.client.setScreen(next);
					return true;
				}
			}
		}
		return super.mouseClicked(mx, my, button);
	}

	/** Sichqoncha ostidagi kartochka raqami yoki -1. */
	private int cardAt(double mx, double my) {
		if (my < listY() || my >= listY() + listH()) return -1;
		for (int i = 0; i < optionCount(); i++) {
			if (Gfx.inside(mx, my, contentX(), cardY(i), contentW(), CARD_H)) return i;
		}
		return -1;
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
		if (Gfx.inside(mx, my, contentX(), listY(), contentW(), listH())) {
			scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) (vertical * 18)));
			return true;
		}
		return super.mouseScrolled(mx, my, horizontal, vertical);
	}

	/** PNG faylni oynaga tashlash: skinlar papkasiga ko'chiriladi va darhol tanlanadi. */
	@Override
	public void onFilesDropped(List<Path> paths) {
		for (Path p : paths) {
			String n = p.getFileName().toString();
			if (!n.toLowerCase(java.util.Locale.ROOT).endsWith(".png")) continue;
			try {
				Files.copy(p, CustomSkin.dir().resolve(n), StandardCopyOption.REPLACE_EXISTING);
				CosmeticsConfig.get().skinFile = n;
				CustomSkin.markDirty();
				CosmeticsConfig.save();
				skinFiles = CustomSkin.list();
				selected = slots.size();
				scroll = 0;
			} catch (Exception e) {
				CosmeticsMod.LOGGER.warn("Skin ko'chirilmadi", e);
			}
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		CosmeticsConfig.save();
		this.client.setScreen(parent);
	}
}
