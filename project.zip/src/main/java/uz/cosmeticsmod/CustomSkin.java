package uz.cosmeticsmod;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/** O'yinchining o'z skini: .minecraft/config/cosmetics_skins/*.png (64x64). Faqat sizga ko'rinadi. */
public final class CustomSkin {
	public static final Identifier ID = Identifier.of(CosmeticsMod.MOD_ID, "custom_skin");
	private static boolean dirty = true;
	private static boolean loaded = false;

	private CustomSkin() {}

	public static Path dir() {
		Path d = FabricLoader.getInstance().getConfigDir().resolve("cosmetics_skins");
		try { Files.createDirectories(d); } catch (Exception ignored) {}
		return d;
	}

	public static List<String> list() {
		List<String> out = new ArrayList<>();
		try (Stream<Path> s = Files.list(dir())) {
			s.forEach(p -> {
				String n = p.getFileName().toString();
				if (n.toLowerCase(Locale.ROOT).endsWith(".png")) out.add(n);
			});
		} catch (Exception ignored) {}
		Collections.sort(out);
		return out;
	}

	public static void markDirty() {
		dirty = true;
	}

	/** Tanlangan skin tekstura identifikatori; skin tanlanmagan yoki o'qilmasa null. Faqat render oqimida chaqiriladi. */
	public static Identifier textureOrNull() {
		String f = CosmeticsConfig.get().skinFile;
		if (f == null || f.isEmpty()) return null;
		if (dirty) {
			dirty = false;
			loaded = load(f);
		}
		return loaded ? ID : null;
	}

	private static boolean load(String file) {
		try (InputStream in = Files.newInputStream(dir().resolve(file))) {
			NativeImage img = NativeImage.read(in);
			if (img.getWidth() != 64 || img.getHeight() != 64) {
				CosmeticsMod.LOGGER.warn("Skin 64x64 bo'lishi kerak: {} ({}x{})", file, img.getWidth(), img.getHeight());
				img.close();
				return false;
			}
			MinecraftClient.getInstance().getTextureManager().registerTexture(ID, new NativeImageBackedTexture(img));
			return true;
		} catch (Exception e) {
			CosmeticsMod.LOGGER.warn("Skin o'qilmadi: " + file, e);
			return false;
		}
	}
}
