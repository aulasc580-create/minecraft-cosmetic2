package uz.cosmeticsmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Vizual effektlar: sakrash doirasi (jump circle) va iz (trail). Faqat sizga ko'rinadi. */
public final class EffectsManager {
	private static final Identifier RING = Identifier.of(CosmeticsMod.MOD_ID, "textures/fx/ring.png");
	private static final Identifier TRAIL = Identifier.of(CosmeticsMod.MOD_ID, "textures/fx/trail.png");
	private static final int RING_LIFE = 16;
	private static final int TRAIL_LIFE = 30;

	/** x, y, z, yosh (tik) */
	private static final List<double[]> rings = new ArrayList<>();
	private static final List<double[]> trail = new ArrayList<>();
	private static boolean wasGround = true;
	private static long ticks;

	private EffectsManager() {}

	public static void tick(MinecraftClient mc) {
		ClientPlayerEntity p = mc.player;
		if (p == null || mc.world == null) {
			rings.clear();
			trail.clear();
			return;
		}
		ticks++;
		CosmeticsConfig cfg = CosmeticsConfig.get();

		boolean ground = p.isOnGround();
		if (cfg.jumpCircle && wasGround && !ground && p.getVelocity().y > 0.1) {
			rings.add(new double[]{p.getX(), p.getY(), p.getZ(), 0});
		}
		wasGround = ground;
		for (double[] r : rings) r[3]++;
		rings.removeIf(r -> r[3] > RING_LIFE);

		for (double[] t : trail) t[3]++;
		trail.removeIf(t -> t[3] > TRAIL_LIFE);
		if (cfg.trail) {
			if (trail.isEmpty()) {
				trail.add(new double[]{p.getX(), p.getY(), p.getZ(), 0});
			} else {
				double[] last = trail.get(trail.size() - 1);
				double dx = p.getX() - last[0], dy = p.getY() - last[1], dz = p.getZ() - last[2];
				if (dx * dx + dy * dy + dz * dz > 0.04) {
					trail.add(new double[]{p.getX(), p.getY(), p.getZ(), 0});
				}
			}
		} else {
			trail.clear();
		}
	}

	/** Effekt rangi (0xRRGGBB). phase - kamalak uchun siljish. */
	private static int rgb(float phase) {
		String c = CosmeticsConfig.get().effectColor;
		switch (c == null ? "theme" : c) {
			case "violet": return 0xA855F7;
			case "pink": return 0xFF4FA8;
			case "blue": return 0x3B82F6;
			case "rainbow": return MathHelper.hsvToRgb(((ticks * 0.01f) + phase) % 1f, 0.85f, 1f);
			default: return Theme.current().accent & 0xFFFFFF;
		}
	}

	public static void render(WorldRenderContext ctx) {
		CosmeticsConfig cfg = CosmeticsConfig.get();
		if (!cfg.jumpCircle && !cfg.trail) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		MatrixStack matrices = ctx.matrixStack();
		VertexConsumerProvider consumers = ctx.consumers();
		if (matrices == null || consumers == null || mc.player == null || mc.world == null) return;

		float td = mc.getRenderTickCounter().getTickDelta(false);
		Vec3d cam = ctx.camera().getPos();
		int light = LightmapTextureManager.MAX_LIGHT_COORDINATES;

		if (cfg.jumpCircle && !rings.isEmpty()) {
			RenderLayer layer = RenderLayer.getEntityTranslucent(RING);
			VertexConsumer vc = consumers.getBuffer(layer);
			matrices.push();
			MatrixStack.Entry e = matrices.peek();
			int col = rgb(0f);
			for (double[] r : rings) {
				float t = (float) ((r[3] + td) / RING_LIFE);
				float ease = 1f - (1f - t) * (1f - t);
				for (int k = 0; k < 2; k++) {
					float radius = (0.3f + 1.7f * ease) * (k == 0 ? 1f : 0.62f);
					float alpha = Math.max(0f, (1f - t) * (k == 0 ? 0.95f : 0.6f));
					float cx = (float) (r[0] - cam.x), cy = (float) (r[1] + 0.03 + k * 0.01 - cam.y), cz = (float) (r[2] - cam.z);
					quad(vc, e, cx - radius, cy, cz - radius, 0, 0, cx - radius, cy, cz + radius, 0, 1,
							cx + radius, cy, cz + radius, 1, 1, cx + radius, cy, cz - radius, 1, 0, col, alpha, light);
				}
			}
			matrices.pop();
			if (consumers instanceof VertexConsumerProvider.Immediate imm) imm.draw(layer);
		}

		if (cfg.trail && !trail.isEmpty()) {
			List<double[]> pts = new ArrayList<>(trail);
			Vec3d me = mc.player.getLerpedPos(td);
			pts.add(new double[]{me.x, me.y, me.z, 0});
			int n = pts.size();
			if (n >= 2) {
				RenderLayer layer = RenderLayer.getEntityTranslucent(TRAIL);
				VertexConsumer vc = consumers.getBuffer(layer);
				matrices.push();
				MatrixStack.Entry e = matrices.peek();
				float[] lx = new float[n], rx = new float[n], lz = new float[n], rz = new float[n], yy = new float[n], al = new float[n];
				for (int i = 0; i < n; i++) {
					double[] a = pts.get(Math.max(0, i - 1)), b = pts.get(Math.min(n - 1, i + 1)), c = pts.get(i);
					double dx = b[0] - a[0], dz = b[2] - a[2];
					double len = Math.sqrt(dx * dx + dz * dz);
					if (len < 1e-6) { dx = 1; dz = 0; len = 1; }
					double sx = -dz / len, sz = dx / len;
					float life = (float) Math.min(1.0, (c[3] + (i == n - 1 ? 0 : td)) / TRAIL_LIFE);
					float hw = 0.22f * (1f - life * 0.7f);
					lx[i] = (float) (c[0] - cam.x + sx * hw); lz[i] = (float) (c[2] - cam.z + sz * hw);
					rx[i] = (float) (c[0] - cam.x - sx * hw); rz[i] = (float) (c[2] - cam.z - sz * hw);
					yy[i] = (float) (c[1] + 0.06 - cam.y);
					al[i] = Math.max(0f, (1f - life) * 0.85f);
				}
				for (int i = 0; i < n - 1; i++) {
					int col = rgb(i * 0.03f);
					quadStrip(vc, e, lx[i], rx[i], lz[i], rz[i], yy[i], al[i], lx[i + 1], rx[i + 1], lz[i + 1], rz[i + 1], yy[i + 1], al[i + 1], col, light);
				}
				matrices.pop();
				if (consumers instanceof VertexConsumerProvider.Immediate imm) imm.draw(layer);
			}
		}
	}

	private static void v(VertexConsumer vc, MatrixStack.Entry e, float x, float y, float z, float u, float vv, int rgb, float a, int light) {
		vc.vertex(e, x, y, z)
				.color((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, Math.max(0, Math.min(255, (int) (a * 255))))
				.texture(u, vv)
				.overlay(OverlayTexture.DEFAULT_UV)
				.light(light)
				.normal(e, 0f, 1f, 0f);
	}

	private static void quad(VertexConsumer vc, MatrixStack.Entry e,
							 float x1, float y1, float z1, float u1, float v1,
							 float x2, float y2, float z2, float u2, float v2,
							 float x3, float y3, float z3, float u3, float v3,
							 float x4, float y4, float z4, float u4, float v4,
							 int rgb, float a, int light) {
		v(vc, e, x1, y1, z1, u1, v1, rgb, a, light);
		v(vc, e, x2, y2, z2, u2, v2, rgb, a, light);
		v(vc, e, x3, y3, z3, u3, v3, rgb, a, light);
		v(vc, e, x4, y4, z4, u4, v4, rgb, a, light);
	}

	private static void quadStrip(VertexConsumer vc, MatrixStack.Entry e,
								  float lx0, float rx0, float lz0, float rz0, float y0, float a0,
								  float lx1, float rx1, float lz1, float rz1, float y1, float a1,
								  int rgb, int light) {
		v(vc, e, lx0, y0, lz0, 0f, 0.5f, rgb, a0, light);
		v(vc, e, rx0, y0, rz0, 1f, 0.5f, rgb, a0, light);
		v(vc, e, rx1, y1, rz1, 1f, 0.5f, rgb, a1, light);
		v(vc, e, lx1, y1, lz1, 0f, 0.5f, rgb, a1, light);
	}
}
