package uz.cosmeticsmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;

/** Freelook: tugmani bosib turganda kamera o'yinchining qarashidan mustaqil aylanadi. */
public final class FreelookManager {
	public static boolean active;
	public static float yaw, pitch;
	private static Perspective before;
	public static KeyBinding key;

	private FreelookManager() {}

	public static void tick(MinecraftClient mc) {
		CosmeticsConfig cfg = CosmeticsConfig.get();
		boolean want = cfg.freelook && key != null && key.isPressed() && mc.player != null && mc.currentScreen == null;
		if (want && !active) {
			active = true;
			yaw = mc.player.getYaw();
			pitch = mc.player.getPitch();
			if (cfg.freelookThird) {
				before = mc.options.getPerspective();
				mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
			}
		} else if (!want && active) {
			active = false;
			if (before != null) {
				mc.options.setPerspective(before);
				before = null;
			}
		}
	}

	/** Sichqoncha harakati (Entity.changeLookDirection o'rniga). */
	public static void turn(double dx, double dy) {
		float s = 0.15f * CosmeticsConfig.get().freelookSens;
		yaw += (float) dx * s;
		pitch += (float) dy * s;
		if (pitch > 90f) pitch = 90f;
		if (pitch < -90f) pitch = -90f;
	}
}
