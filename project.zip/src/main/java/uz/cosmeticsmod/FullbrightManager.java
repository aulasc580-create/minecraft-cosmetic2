package uz.cosmeticsmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import uz.cosmeticsmod.mixin.SimpleOptionAccessor;

/** Fullbright: yorqinlik (gamma) qiymatini cheklovsiz oshiradi; o'chirilganda asl qiymat qaytariladi. */
public final class FullbrightManager {
	private static boolean active;
	private static double saved = 1.0;

	private FullbrightManager() {}

	@SuppressWarnings("unchecked")
	private static void set(SimpleOption<Double> opt, double v) {
		((SimpleOptionAccessor<Double>) (Object) opt).cosmetics$setValue(v);
	}

	public static void tick(MinecraftClient mc) {
		if (mc.options == null) return;
		SimpleOption<Double> gamma = mc.options.getGamma();
		CosmeticsConfig cfg = CosmeticsConfig.get();
		if (cfg.fullbright) {
			if (!active) {
				saved = gamma.getValue();
				active = true;
			}
			if (Math.abs(gamma.getValue() - cfg.fullbrightGamma) > 0.01) set(gamma, cfg.fullbrightGamma);
		} else if (active) {
			set(gamma, saved);
			active = false;
		}
	}

	/** O'yin yopilishida options.txt ga katta gamma yozilib qolmasligi uchun. */
	public static void restore(MinecraftClient mc) {
		if (active && mc.options != null) {
			set(mc.options.getGamma(), saved);
			active = false;
		}
	}
}
