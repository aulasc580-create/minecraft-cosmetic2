package uz.cosmeticsmod;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Menyu uchun chizish yordamchilari: yumaloq to'rtburchak, matn, shisha (liquid glass) ranglari, logo. */
public final class Gfx {
	private Gfx() {}

	// ---- yumaloq shakllar ----
	/** Menyu uslubidagi yumaloq to'rtburchak: radius sozlamadagi "Rounded Menu" ga qarab masshtablanadi. */
	public static void roundRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
		roundRectRaw(ctx, x, y, w, h, rad(r), color);
	}

	/** Radiusi aynan berilgan (HUD uchun). */
	public static void roundRectRaw(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
		r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		if (r == 0) {
			ctx.fill(x, y, x + w, y + h, color);
			return;
		}
		ctx.fill(x, y + r, x + w, y + h - r, color);
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = r - (int) Math.round(Math.sqrt(Math.max(0, (double) r * r - dy * dy)));
			ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
			ctx.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
		}
	}

	/** 20 = to'liq yumaloq; "Rounded Menu" o'chiq bo'lsa deyarli to'g'ri burchak. */
	public static int rad(int base) {
		CosmeticsConfig c = CosmeticsConfig.get();
		float radius = c.roundedMenu ? c.menuRadius : 2f;
		return Math.max(0, Math.round(base * radius / 20f));
	}

	// ---- shisha (liquid glass) ranglari ----
	public static boolean glass() { return CosmeticsConfig.get().liquidGlass; }

	public static int alpha(int argb, int a) { return (a << 24) | (argb & 0xFFFFFF); }

	public static int panel(Theme t) {
		return glass() ? alpha(t.panel, (int) (CosmeticsConfig.get().glassAlpha * 255)) : t.panel;
	}
	public static int side(Theme t) { return glass() ? alpha(t.side, 0x66) : t.side; }
	public static int card(Theme t) { return glass() ? alpha(t.card, 0x88) : t.card; }
	public static int cardHover(Theme t) { return glass() ? alpha(t.cardHover, 0xAA) : t.cardHover; }
	public static int border(Theme t) { return glass() ? 0x66FFFFFF : t.border; }

	/** Shisha porlashi: yuqori yarmida nozik oq yaltiroq qatlam. */
	public static void sheen(DrawContext ctx, int x, int y, int w, int h, int r) {
		if (!glass()) return;
		roundRect(ctx, x + 2, y + 2, w - 4, h / 2, r, 0x14FFFFFF);
	}

	// ---- matn ----
	/** align: 0 = chapdan, 1 = markazdan, 2 = o'ngdan. */
	public static void text(DrawContext ctx, TextRenderer tr, Text text, int x, int y, float scale, int color, int align) {
		float w = tr.getWidth(text) * scale;
		float dx = align == 1 ? x - w / 2f : (align == 2 ? x - w : x);
		ctx.getMatrices().push();
		ctx.getMatrices().translate(dx, (float) y, 0f);
		ctx.getMatrices().scale(scale, scale, 1f);
		ctx.drawTextWithShadow(tr, text, 0, 0, color);
		ctx.getMatrices().pop();
	}

	public static boolean inside(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	// ---- logo ----
	/** Lumora logosini (yumaloq) chizadi. big = 24x24, aks holda 14x14 piksel. */
	public static void logo(DrawContext ctx, int x, int y, boolean big) {
		int n = big ? LogoData.N24 : LogoData.N14;
		int[] p = big ? LogoData.P24 : LogoData.P14;
		for (int j = 0; j < n; j++) {
			for (int i = 0; i < n; i++) {
				int c = p[j * n + i];
				if ((c >>> 24) < 20) continue;
				ctx.fill(x + i, y + j, x + i + 1, y + j + 1, c | 0xFF000000);
			}
		}
	}
}
