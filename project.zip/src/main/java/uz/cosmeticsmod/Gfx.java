package uz.cosmeticsmod;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Menyu uchun kichik chizish yordamchilari: yumaloq to'rtburchak va kattalashtirilgan matn. */
public final class Gfx {
	private Gfx() {}

	/** Burchaklari r radiusda yumaloqlangan to'ldirilgan to'rtburchak. */
	public static void roundRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
		r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		if (r == 0) {
			ctx.fill(x, y, x + w, y + h, color);
			return;
		}
		ctx.fill(x, y + r, x + w, y + h - r, color);
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = r - (int) Math.round(Math.sqrt(Math.max(0, (double) r * r - dy * dy)));
			ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
			ctx.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
		}
	}

	/** align: 0 = chapdan, 1 = markazdan, 2 = o'ngdan. */
	public static void text(DrawContext ctx, TextRenderer tr, Text text, int x, int y, float scale, int color, int align) {
		float w = tr.getWidth(text) * scale;
		float dx = align == 1 ? x - w / 2f : (align == 2 ? x - w : x);
		ctx.getMatrices().push();
		ctx.getMatrices().translate(dx, (float) y, 0f);
		ctx.getMatrices().scale(scale, scale, 1f);
		ctx.drawTextWithShadow(tr, text, 0, 0, color);
		ctx.getMatrices().pop();
	}

	public static boolean inside(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}
}
