package uz.cosmeticsmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** O'yin ichidagi HUD'lar: Target HUD, Potions HUD, Module List, Durability HUD. */
public final class HudManager {
	private static float shownHp = -1f;
	private static LivingEntity lastTarget;

	private HudManager() {}

	public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
		MinecraftClient mc = MinecraftClient.getInstance();
		ClientPlayerEntity p = mc.player;
		if (p == null || mc.options.hudHidden) return;
		CosmeticsConfig cfg = CosmeticsConfig.get();
		Theme th = Theme.current();
		if (cfg.targetHud) targetHud(ctx, mc, th, cfg);
		if (cfg.potionsHud) potionsHud(ctx, mc, p, th, cfg);
		if (cfg.moduleList) moduleList(ctx, mc, th, cfg);
		if (cfg.durabilityHud) durabilityHud(ctx, mc, p, th, cfg);
	}

	private static void pill(DrawContext ctx, int x, int y, int w, int h) {
		Gfx.roundRectRaw(ctx, x, y, w, h, h / 2 < 8 ? h / 2 : 8, 0xB00A0A12);
	}

	// ---------------- Target HUD ----------------
	private static void targetHud(DrawContext ctx, MinecraftClient mc, Theme th, CosmeticsConfig cfg) {
		LivingEntity t = TargetTracker.current(mc);
		if (t == null) {
			shownHp = -1f;
			lastTarget = null;
			return;
		}
		if (t != lastTarget) {
			lastTarget = t;
			shownHp = t.getHealth();
		}
		shownHp += (t.getHealth() - shownHp) * 0.15f;
		float max = Math.max(1f, t.getMaxHealth());
		float frac = MathHelper.clamp(shownHp / max, 0f, 1f);

		int w = 150, h = 42;
		int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
		int x = cfg.targetPos == 0 ? sw / 2 + 24 : (sw - w) / 2;
		int y = cfg.targetPos == 0 ? sh / 2 + 14 : sh - 96;
		Gfx.roundRectRaw(ctx, x - 1, y - 1, w + 2, h + 2, 13, th.accent & 0xFFFFFF | 0x66000000);
		Gfx.roundRectRaw(ctx, x, y, w, h, 12, 0xD00A0A12);
		String name = t.getName().getString();
		ctx.drawTextWithShadow(mc.textRenderer, name, x + 10, y + 7, 0xFFFFFFFF);
		String hp = String.format("%.1f HP", t.getHealth());
		ctx.drawTextWithShadow(mc.textRenderer, hp, x + w - 10 - mc.textRenderer.getWidth(hp), y + 7, th.accent);
		int bx = x + 10, by = y + 24, bw = w - 20;
		Gfx.roundRectRaw(ctx, bx, by, bw, 8, 4, 0xFF1A1A26);
		int fw = Math.max(0, Math.round(bw * frac));
		if (fw > 0) Gfx.roundRectRaw(ctx, bx, by, fw, 8, 4, healthColor(frac, th));
	}

	private static int healthColor(float f, Theme th) {
		if (f > 0.6f) return th.accent | 0xFF000000;
		if (f > 0.3f) return 0xFFF5C542;
		return 0xFFEF4444;
	}

	// ---------------- Potions HUD ----------------
	private static void potionsHud(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p, Theme th, CosmeticsConfig cfg) {
		Collection<StatusEffectInstance> effects = p.getStatusEffects();
		if (effects.isEmpty()) return;
		int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
		int rowH = 17, w = 124;
		int total = effects.size() * (rowH + 3);
		int x = cfg.potionsPos == 0 ? 6 : sw - w - 6;
		int y = Math.max(30, sh / 2 - total / 2);
		for (StatusEffectInstance e : effects) {
			String name = e.getEffectType().value().getName().getString();
			if (e.getAmplifier() > 0) name += " " + (e.getAmplifier() + 1);
			int dur = e.getDuration();
			String time = dur < 0 || dur > 99999 ? "inf" : String.format("%d:%02d", dur / 1200, (dur / 20) % 60);
			pill(ctx, x, y, w, rowH);
			int col = 0xFF000000 | e.getEffectType().value().getColor();
			Gfx.roundRectRaw(ctx, x + 6, y + 5, 7, 7, 3, col);
			ctx.drawTextWithShadow(mc.textRenderer, name, x + 18, y + 5, 0xFFFFFFFF);
			ctx.drawTextWithShadow(mc.textRenderer, time, x + w - 6 - mc.textRenderer.getWidth(time), y + 5,
					dur >= 0 && dur < 200 ? 0xFFEF4444 : th.accent);
			y += rowH + 3;
		}
	}

	// ---------------- Module List ----------------
	private static void moduleList(DrawContext ctx, MinecraftClient mc, Theme th, CosmeticsConfig cfg) {
		List<String> names = new ArrayList<>();
		for (Modules.Mod m : Modules.EFFECTS) if (m.get().get()) names.add(m.name());
		for (Modules.Mod m : Modules.VISUALS) {
			if (m.get().get() && !m.name().startsWith("Menu") && !m.name().startsWith("Liquid") && !m.name().startsWith("Rounded")) {
				names.add(m.name());
			}
		}
		if (cfg.autoSprint && !names.contains("Auto Sprint")) names.add("Auto Sprint");
		if (names.isEmpty()) return;
		names.sort((a, b) -> mc.textRenderer.getWidth(b) - mc.textRenderer.getWidth(a));
		int sw = mc.getWindow().getScaledWidth();
		int y = 6;
		for (String n : names) {
			int tw = mc.textRenderer.getWidth(n);
			int w = tw + 14, h = 14;
			int x = cfg.moduleListPos == 0 ? sw - w - 6 : 6;
			Gfx.roundRectRaw(ctx, x, y, w, h, 6, 0xA00A0A12);
			int bar = th.accent | 0xFF000000;
			if (cfg.moduleListPos == 0) ctx.fill(x + w - 3, y + 3, x + w - 2, y + h - 3, bar);
			else ctx.fill(x + 2, y + 3, x + 3, y + h - 3, bar);
			ctx.drawTextWithShadow(mc.textRenderer, n, x + (cfg.moduleListPos == 0 ? 6 : 8), y + 3, 0xFFFFFFFF);
			y += h + 2;
		}
	}

	// ---------------- Durability HUD ----------------
	private static void durabilityHud(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p, Theme th, CosmeticsConfig cfg) {
		EquipmentSlot[] order = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND};
		List<ItemStack> stacks = new ArrayList<>();
		for (EquipmentSlot s : order) {
			ItemStack st = p.getEquippedStack(s);
			if (!st.isEmpty() && st.isDamageable()) stacks.add(st);
		}
		if (stacks.isEmpty()) return;
		int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
		int rowH = 20, w = 82;
		int total = stacks.size() * (rowH + 2);
		int x = cfg.durabilityPos == 0 ? 6 : sw - w - 6;
		int y = sh - 60 - total;
		for (ItemStack st : stacks) {
			pill(ctx, x, y, w, rowH);
			ctx.drawItem(st, x + 2, y + 2);
			int max = st.getMaxDamage();
			float f = MathHelper.clamp(1f - st.getDamage() / (float) max, 0f, 1f);
			int col = f > 0.5f ? 0xFF4ADE80 : (f > 0.2f ? 0xFFF5C542 : 0xFFEF4444);
			Gfx.roundRectRaw(ctx, x + 22, y + 13, 52, 4, 2, 0xFF1A1A26);
			int fw = Math.max(1, Math.round(52 * f));
			Gfx.roundRectRaw(ctx, x + 22, y + 13, fw, 4, 2, col);
			String pct = Math.round(f * 100) + "%";
			ctx.drawTextWithShadow(mc.textRenderer, pct, x + 22, y + 3, 0xFFFFFFFF);
			y += rowH + 2;
		}
	}
}
