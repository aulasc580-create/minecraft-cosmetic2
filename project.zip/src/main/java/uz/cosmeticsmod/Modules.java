package uz.cosmeticsmod;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Yoqish/o'chirish mumkin bo'lgan modullar ro'yxati (menyudagi "Effects" va "Visuals" bo'limlari). */
public final class Modules {
	private Modules() {}

	public record Mod(String name, Supplier<Boolean> get, Consumer<Boolean> set) {}

	private static CosmeticsConfig c() { return CosmeticsConfig.get(); }

	public static final List<Mod> EFFECTS = List.of(
			new Mod("Jump Circle", () -> c().jumpCircle, v -> c().jumpCircle = v),
			new Mod("Trail", () -> c().trail, v -> c().trail = v),
			new Mod("Watermark", () -> c().watermark, v -> c().watermark = v),
			new Mod("Stretched Screen", () -> c().aspectRatio, v -> c().aspectRatio = v));

	public static final List<Mod> VISUALS = List.of(
			new Mod("Fullbright", () -> c().fullbright, v -> c().fullbright = v),
			new Mod("Viewmodel", () -> c().viewmodel, v -> c().viewmodel = v),
			new Mod("Target ESP", () -> c().targetEsp, v -> c().targetEsp = v),
			new Mod("Target HUD", () -> c().targetHud, v -> c().targetHud = v),
			new Mod("Potions HUD", () -> c().potionsHud, v -> c().potionsHud = v),
			new Mod("Module List", () -> c().moduleList, v -> c().moduleList = v),
			new Mod("Durability HUD", () -> c().durabilityHud, v -> c().durabilityHud = v),
			new Mod("Freelook", () -> c().freelook, v -> c().freelook = v),
			new Mod("Auto Sprint", () -> c().autoSprint, v -> c().autoSprint = v),
			new Mod("Client Sound", () -> c().clientSound, v -> c().clientSound = v),
			new Mod("Menu Blur", () -> c().menuBlur, v -> c().menuBlur = v),
			new Mod("Liquid Glass", () -> c().liquidGlass, v -> c().liquidGlass = v),
			new Mod("Rounded Menu", () -> c().roundedMenu, v -> c().roundedMenu = v));

	public static boolean anyEffectOn() {
		for (Mod m : EFFECTS) if (m.get().get()) return true;
		return false;
	}

	public static boolean anyVisualOn() {
		for (Mod m : VISUALS) if (m.get().get()) return true;
		return false;
	}
}
