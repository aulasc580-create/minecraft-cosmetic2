package uz.cosmeticsmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;

/** Pet: o'yinchining o'ng yelkasi tepasida o'tiradi (faqat sizga ko'rinadi). */
public final class PetManager {
	private static int ticks;

	private PetManager() {}

	public static void tick(MinecraftClient mc) {
		ticks++;
	}

	public static void render(WorldRenderContext ctx) {
		MinecraftClient mc = MinecraftClient.getInstance();
		ClientPlayerEntity p = mc.player;
		Cosmetic pet = CosmeticsConfig.get().equippedIn(CosmeticSlot.PET);
		MatrixStack matrices = ctx.matrixStack();
		VertexConsumerProvider consumers = ctx.consumers();
		if (pet == null || p == null || matrices == null || consumers == null || mc.world == null) return;

		CosmeticsConfig cfg = CosmeticsConfig.get();
		float td = mc.getRenderTickCounter().getTickDelta(false);
		Vec3d cam = ctx.camera().getPos();
		Vec3d pos = p.getLerpedPos(td);
		float yaw = MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw);
		double yawRad = Math.toRadians(yaw);
		double rx = -Math.cos(yawRad), rz = -Math.sin(yawRad); // o'yinchining o'ng tomoni
		double fx = -Math.sin(yawRad), fz = Math.cos(yawRad);  // old tomoni

		float s = pet.petScale * cfg.sizeOf(pet);
		float bob = (float) Math.sin((ticks + td) * 0.12) * pet.petBob * 0.4f;
		double shoulderY = (p.isSneaking() ? 1.15 : 1.42) + pet.petHover + cfg.heightOf(pet) + bob;
		double x = pos.x + rx * 0.36 - fx * 0.02;
		double y = pos.y + shoulderY;
		double z = pos.z + rz * 0.36 - fz * 0.02;

		BlockPos bp = BlockPos.ofFloored(pos.x, pos.y + 1.0, pos.z);
		int light = LightmapTextureManager.pack(
				mc.world.getLightLevel(LightType.BLOCK, bp), mc.world.getLightLevel(LightType.SKY, bp));

		matrices.push();
		matrices.translate(x - cam.x, y - cam.y, z - cam.z);
		matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
		matrices.scale(s, s, s);
		RenderLayer layer = RenderLayer.getEntityCutoutNoCull(pet.texture);
		VertexConsumer vc = consumers.getBuffer(layer);
		pet.mesh().render(matrices.peek(), vc, light, OverlayTexture.DEFAULT_UV);
		matrices.pop();
		if (consumers instanceof VertexConsumerProvider.Immediate imm) imm.draw(layer);
	}
}
