package uz.cosmeticsmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;

/** Pet: o'yinchini ergashib yuradi (faqat sizga ko'rinadi). Har tikda joyi yangilanadi, har kadrda chiziladi. */
public final class PetManager {
	private static Vec3d prev = Vec3d.ZERO, cur = Vec3d.ZERO;
	private static float prevYaw, curYaw;
	private static boolean has;
	private static int ticks;

	private PetManager() {}

	public static void tick(MinecraftClient mc) {
		ClientPlayerEntity p = mc.player;
		Cosmetic pet = CosmeticsConfig.get().equippedIn(CosmeticSlot.PET);
		if (p == null || mc.world == null || pet == null) {
			has = false;
			return;
		}
		ticks++;
		float size = pet.petScale * CosmeticsConfig.get().sizeOf(pet);
		double yawRad = Math.toRadians(p.getYaw());
		double fx = -Math.sin(yawRad), fz = Math.cos(yawRad);   // o'yinchi qaragan tomon
		double rx = -Math.cos(yawRad), rz = -Math.sin(yawRad);  // o'yinchining o'ng tomoni
		double dist = 1.0 + 0.6 * size;
		Vec3d pp = p.getPos();
		double tx = pp.x - fx * dist * 0.7 + rx * dist;
		double ty = pp.y;
		double tz = pp.z - fz * dist * 0.7 + rz * dist;

		if (!has || cur.squaredDistanceTo(tx, ty, tz) > 24 * 24) {
			cur = new Vec3d(tx, ty, tz);
			prev = cur;
			curYaw = prevYaw = p.getYaw();
			has = true;
			return;
		}
		prev = cur;
		prevYaw = curYaw;
		double dx = tx - cur.x, dz = tz - cur.z;
		double hd = Math.sqrt(dx * dx + dz * dz);
		double nx = cur.x + dx * 0.18;
		double nz = cur.z + dz * 0.18;
		double ny = cur.y + (ty - cur.y) * 0.25;
		cur = new Vec3d(nx, ny, nz);
		float desired = hd > 0.25 ? (float) Math.toDegrees(Math.atan2(-dx, dz)) : p.getYaw();
		curYaw = prevYaw + MathHelper.wrapDegrees(desired - prevYaw) * 0.2f;
	}

	public static void render(WorldRenderContext ctx) {
		if (!has) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		Cosmetic pet = CosmeticsConfig.get().equippedIn(CosmeticSlot.PET);
		MatrixStack matrices = ctx.matrixStack();
		VertexConsumerProvider consumers = ctx.consumers();
		if (pet == null || matrices == null || consumers == null || mc.world == null) return;

		float td = mc.getRenderTickCounter().getTickDelta(false);
		Vec3d cam = ctx.camera().getPos();
		double x = MathHelper.lerp(td, prev.x, cur.x);
		double y = MathHelper.lerp(td, prev.y, cur.y);
		double z = MathHelper.lerp(td, prev.z, cur.z);
		float yaw = prevYaw + MathHelper.wrapDegrees(curYaw - prevYaw) * td;
		float bob = (float) Math.sin((ticks + td) * 0.12) * pet.petBob;
		float s = pet.petScale * CosmeticsConfig.get().sizeOf(pet);

		BlockPos bp = BlockPos.ofFloored(x, y + 0.5, z);
		int light = LightmapTextureManager.pack(
				mc.world.getLightLevel(LightType.BLOCK, bp), mc.world.getLightLevel(LightType.SKY, bp));

		matrices.push();
		matrices.translate(x - cam.x, y + pet.petHover + bob - cam.y, z - cam.z);
		matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
		matrices.scale(s, s, s);
		RenderLayer layer = RenderLayer.getEntityCutoutNoCull(pet.texture);
		VertexConsumer vc = consumers.getBuffer(layer);
		pet.mesh().render(matrices.peek(), vc, light, OverlayTexture.DEFAULT_UV);
		matrices.pop();
		if (consumers instanceof VertexConsumerProvider.Immediate imm) imm.draw(layer);
	}
}
