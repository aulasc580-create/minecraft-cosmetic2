package uz.cosmeticsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/** Bitta narsa (cosmetic / effekt / watermark / skin) uchun alohida sozlamalar oynasi. O'ng tugma bilan ochiladi. */
public class SettingsScreen extends Screen {
	private static final int PW = 320, ROW_H = 36, GAP = 5, HEADER_H = 46, FOOTER_H = 46, PAD = 14;

	private enum Kind { SLIDER, TOGGLE, CHOICE, BUTTON }

	public static final class Row {
		Kind kind;
		String label;
		float min, max, step;
		Supplier<Float> getF;
		Consumer<Float> setF;
		Function<Float, String> fmt;
		Supplier<Boolean> getB;
		Consumer<Boolean> setB;
		String[] options;
		Supplier<Integer> getI;
		Consumer<Integer> setI;
		Runnable action;

		static Row slider(String label, float min, float max, float step, Supplier<Float> get, Consumer<Float> set, Function<Float, String> fmt) {
			Row r = new Row(); r.kind = Kind.SLIDER; r.label = label; r.min = min; r.max = max; r.step = step;
			r.getF = get; r.setF = set; r.fmt = fmt; return r;
		}
		static Row toggle(String label, Supplier<Boolean> get, Consumer<Boolean> set) {
			Row r = new Row(); r.kind = Kind.TOGGLE; r.label = label; r.getB = get; r.setB = set; return r;
		}
		static Row choice(String label, String[] options, Supplier<Integer> get, Consumer<Integer> set) {
			Row r = new Row(); r.kind = Kind.CHOICE; r.label = label; r.options = options; r.getI = get; r.setI = set; return r;
		}
		static Row button(String label, Runnable action) {
			Row r = new Row(); r.kind = Kind.BUTTON; r.label = label; r.action = action; return r;
		}
	}

	private final Screen parent;
	private final String heading;
	private final List<Row> rows;
	private int px, py, ph;
	private int dragRow = -1;

	public SettingsScreen(Screen parent, String heading, List<Row> rows) {
		super(Text.literal(heading));
		this.parent = parent;
		this.heading = heading;
		this.rows = rows;
	}

	@Override
	protected void init() {
		ph = HEADER_H + rows.size() * (ROW_H + GAP) + FOOTER_H;
		px = (this.width - PW) / 2;
		py = Math.max(4, (this.height - ph) / 2);
	}

	private int rowY(int i) { return py + HEADER_H + i * (ROW_H + GAP); }
	private int trackX() { return px + PAD + 14; }
	private int trackW() { return PW - 2 * PAD - 28; }
	private int backX() { return px + (PW - 120) / 2; }
	private int backY() { return py + ph - 36; }

	@Override
	public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
		Theme t = Theme.current();
		CosmeticsConfig gc = CosmeticsConfig.get();
		if ((gc.menuBlur || gc.liquidGlass) && this.client != null && this.client.world != null) {
			super.renderBackground(ctx, mx, my, delta);
		} else {
			ctx.fill(0, 0, this.width, this.height, 0xB0000000);
		}
		Gfx.roundRect(ctx, px - 1, py - 1, PW + 2, ph + 2, 17, Gfx.border(t));
		Gfx.roundRect(ctx, px, py, PW, ph, 16, Gfx.panel(t));
		Gfx.sheen(ctx, px, py, PW, ph, 14);
		Gfx.text(ctx, this.textRenderer, Text.literal(heading), px + PW / 2, py + 12, 1.3f, 0xFFF4F0FF, 1);
		Gfx.text(ctx, this.textRenderer, Text.literal("Settings"), px + PW / 2, py + 29, 0.85f, t.accent, 1);

		for (int i = 0; i < rows.size(); i++) {
			Row r = rows.get(i);
			int y = rowY(i), x = px + PAD, w = PW - 2 * PAD;
			boolean hov = Gfx.inside(mx, my, x, y, w, ROW_H);
			Gfx.roundRect(ctx, x, y, w, ROW_H, 11, hov && r.kind != Kind.SLIDER ? Gfx.cardHover(t) : Gfx.card(t));
			switch (r.kind) {
				case SLIDER -> {
					float v = r.getF.get();
					Gfx.text(ctx, this.textRenderer, Text.literal(r.label), x + 14, y + 5, 1.0f, t.muted, 0);
					Gfx.text(ctx, this.textRenderer, Text.literal(r.fmt.apply(v)), x + w - 14, y + 5, 1.0f, t.accent, 2);
					int ty = y + 25;
					Gfx.roundRect(ctx, trackX(), ty - 2, trackW(), 5, 2, Gfx.side(t));
					float f = (v - r.min) / (r.max - r.min);
					f = Math.max(0f, Math.min(1f, f));
					int kx = trackX() + Math.round(trackW() * f);
					if (kx > trackX() + 2) Gfx.roundRect(ctx, trackX(), ty - 2, kx - trackX(), 5, 2, t.accent);
					Gfx.roundRect(ctx, kx - 5, ty - 6, 11, 13, 5, dragRow == i ? 0xFFFFFFFF : t.accent);
				}
				case TOGGLE -> {
					boolean on = r.getB.get();
					Gfx.text(ctx, this.textRenderer, Text.literal(r.label), x + 14, y + 14, 1.05f, 0xFFF4F0FF, 0);
					int sx = x + w - 14 - 40, sy = y + 9;
					Gfx.roundRect(ctx, sx, sy, 40, 18, 9, on ? t.accent : Gfx.side(t));
					int kx = on ? sx + 40 - 16 : sx + 2;
					Gfx.roundRect(ctx, kx, sy + 2, 14, 14, 7, 0xFFFFFFFF);
				}
				case CHOICE -> {
					Gfx.text(ctx, this.textRenderer, Text.literal(r.label), x + 14, y + 14, 1.05f, 0xFFF4F0FF, 0);
					int idx = Math.max(0, Math.min(r.options.length - 1, r.getI.get()));
					Gfx.text(ctx, this.textRenderer, Text.literal(r.options[idx] + "  >"), x + w - 14, y + 14, 1.0f, t.accent, 2);
				}
				case BUTTON -> Gfx.text(ctx, this.textRenderer, Text.literal(r.label), x + w / 2, y + 14, 1.05f, 0xFFF4F0FF, 1);
			}
		}

		boolean bh = Gfx.inside(mx, my, backX(), backY(), 120, 24);
		Gfx.roundRect(ctx, backX(), backY(), 120, 24, 12, bh ? t.accent : t.accentSoft);
		Gfx.text(ctx, this.textRenderer, Text.literal("Back"), backX() + 60, backY() + 8, 1.05f, 0xFFF4F0FF, 1);
	}

	private void setSlider(Row r, double mx) {
		float f = (float) ((mx - trackX()) / trackW());
		f = Math.max(0f, Math.min(1f, f));
		float v = r.min + f * (r.max - r.min);
		v = Math.round(v / r.step) * r.step;
		v = Math.max(r.min, Math.min(r.max, v));
		r.setF.accept(v);
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (button != 0) return super.mouseClicked(mx, my, button);
		if (Gfx.inside(mx, my, backX(), backY(), 120, 24)) {
			SoundFx.click();
			this.close();
			return true;
		}
		for (int i = 0; i < rows.size(); i++) {
			Row r = rows.get(i);
			int y = rowY(i), x = px + PAD, w = PW - 2 * PAD;
			if (!Gfx.inside(mx, my, x, y, w, ROW_H)) continue;
			switch (r.kind) {
				case SLIDER -> { dragRow = i; setSlider(r, mx); }
				case TOGGLE -> { boolean nv = !r.getB.get(); r.setB.accept(nv); SoundFx.toggle(nv); CosmeticsConfig.save(); }
				case CHOICE -> { SoundFx.click(); r.setI.accept((r.getI.get() + 1) % r.options.length); CosmeticsConfig.save(); }
				case BUTTON -> { r.action.run(); CosmeticsConfig.save(); }
			}
			return true;
		}
		return super.mouseClicked(mx, my, button);
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (dragRow >= 0 && button == 0) {
			setSlider(rows.get(dragRow), mx);
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		if (dragRow >= 0) {
			dragRow = -1;
			CosmeticsConfig.save();
			return true;
		}
		return super.mouseReleased(mx, my, button);
	}

	@Override
	public boolean shouldPause() { return false; }

	@Override
	public void close() {
		CosmeticsConfig.save();
		this.client.setScreen(parent);
	}

	// ---------- har bir narsa uchun sozlamalar ro'yxati ----------

	public static SettingsScreen forCosmetic(Screen parent, Cosmetic c) {
		CosmeticsConfig cfg = CosmeticsConfig.get();
		List<Row> rows = new ArrayList<>();
		rows.add(Row.slider("Size", 0.3f, 3.0f, 0.05f, () -> cfg.sizeOf(c), v -> cfg.setSize(c, v),
				v -> Math.round(v * 100) + "%"));
		if (c.isPet()) {
			rows.add(Row.slider("Height", -0.5f, 0.5f, 0.02f, () -> cfg.heightOf(c), v -> cfg.setHeight(c, v),
					v -> String.format("%+.2f", v)));
		} else {
			rows.add(Row.slider("Height", -10f, 10f, 0.5f, () -> cfg.heightOf(c), v -> cfg.setHeight(c, v),
					v -> String.format("%+.1f", v)));
		}
		rows.add(Row.button("Reset", () -> { cfg.setSize(c, 1.0f); cfg.setHeight(c, 0f); }));
		return new SettingsScreen(parent, c.displayName().getString(), rows);
	}

	public static SettingsScreen forVisual(Screen parent, int index) {
		CosmeticsConfig cfg = CosmeticsConfig.get();
		List<Row> rows = new ArrayList<>();
		String name;
		switch (index) {
			case 0 -> {
				name = "Jump Circle";
				rows.add(Row.choice("Color", EffectsManager.FX_NAMES, () -> EffectsManager.fxIndex(cfg.jumpColor),
						i -> cfg.jumpColor = EffectsManager.FX_IDS[i]));
				rows.add(Row.slider("Size", 0.5f, 2.0f, 0.05f, () -> cfg.jumpScale, v -> cfg.jumpScale = v,
						v -> Math.round(v * 100) + "%"));
			}
			case 1 -> {
				name = "Trail";
				rows.add(Row.choice("Color", EffectsManager.FX_NAMES, () -> EffectsManager.fxIndex(cfg.trailColor),
						i -> cfg.trailColor = EffectsManager.FX_IDS[i]));
				rows.add(Row.slider("Width", 0.5f, 3.0f, 0.1f, () -> cfg.trailWidth, v -> cfg.trailWidth = v,
						v -> Math.round(v * 100) + "%"));
			}
			case 2 -> {
				name = "Watermark";
				rows.add(Row.toggle("Nickname", () -> cfg.wmName, v -> cfg.wmName = v));
				rows.add(Row.toggle("Ping", () -> cfg.wmPing, v -> cfg.wmPing = v));
				rows.add(Row.toggle("FPS", () -> cfg.wmFps, v -> cfg.wmFps = v));
				rows.add(Row.toggle("Time", () -> cfg.wmTime, v -> cfg.wmTime = v));
			}
			default -> {
				name = "Stretched Screen";
				String[] names = WatermarkHud.RATIO_NAMES;
				String[] opts = new String[names.length + 1];
				System.arraycopy(names, 0, opts, 0, names.length);
				opts[names.length] = "Custom";
				rows.add(Row.choice("Preset", opts, () -> {
					for (int i = 0; i < WatermarkHud.RATIOS.length; i++) {
						if (Math.abs(WatermarkHud.RATIOS[i] - cfg.aspectValue) < 0.005f) return i;
					}
					return WatermarkHud.RATIOS.length;
				}, i -> { if (i < WatermarkHud.RATIOS.length) cfg.aspectValue = WatermarkHud.RATIOS[i]; }));
				rows.add(Row.slider("Ratio", 0.8f, 2.4f, 0.01f, () -> cfg.aspectValue, v -> cfg.aspectValue = v,
						v -> String.format("%.2f", v)));
			}
		}
		return new SettingsScreen(parent, name, rows);
	}

	private static final String[] LR = {"Left", "Right"};

	/** Visuals bo'limidagi modullar sozlamalari (Modules.VISUALS tartibida). */
	public static SettingsScreen forModule(Screen parent, int index) {
		CosmeticsConfig cfg = CosmeticsConfig.get();
		List<Row> rows = new ArrayList<>();
		String name = Modules.VISUALS.get(index).name();
		switch (index) {
			case 0 -> rows.add(Row.slider("Brightness", 2f, 15f, 0.5f, () -> cfg.fullbrightGamma, v -> cfg.fullbrightGamma = v,
					v -> String.format("%.1f", v)));
			case 1 -> {
				rows.add(Row.slider("Offset X", -1f, 1f, 0.02f, () -> cfg.vmX, v -> cfg.vmX = v, v -> String.format("%+.2f", v)));
				rows.add(Row.slider("Offset Y", -1f, 1f, 0.02f, () -> cfg.vmY, v -> cfg.vmY = v, v -> String.format("%+.2f", v)));
				rows.add(Row.slider("Offset Z", -1.5f, 1f, 0.02f, () -> cfg.vmZ, v -> cfg.vmZ = v, v -> String.format("%+.2f", v)));
				rows.add(Row.slider("Scale", 0.3f, 2.0f, 0.05f, () -> cfg.vmScale, v -> cfg.vmScale = v, v -> Math.round(v * 100) + "%"));
				rows.add(Row.button("Reset", () -> { cfg.vmX = 0; cfg.vmY = 0; cfg.vmZ = 0; cfg.vmScale = 1f; }));
			}
			case 2 -> {
				rows.add(Row.choice("Color", EffectsManager.FX_NAMES, () -> EffectsManager.fxIndex(cfg.espColor),
						i -> cfg.espColor = EffectsManager.FX_IDS[i]));
				rows.add(Row.choice("Style", new String[]{"Ring", "Box", "Ring + Box"}, () -> cfg.espStyle, i -> cfg.espStyle = i));
			}
			case 3 -> rows.add(Row.choice("Position", new String[]{"Next to crosshair", "Bottom center"}, () -> cfg.targetPos, i -> cfg.targetPos = i));
			case 4 -> rows.add(Row.choice("Position", LR, () -> cfg.potionsPos, i -> cfg.potionsPos = i));
			case 5 -> rows.add(Row.choice("Position", new String[]{"Right", "Left"}, () -> cfg.moduleListPos, i -> cfg.moduleListPos = i));
			case 6 -> rows.add(Row.choice("Position", LR, () -> cfg.durabilityPos, i -> cfg.durabilityPos = i));
			case 7 -> {
				rows.add(Row.slider("Sensitivity", 0.2f, 2.0f, 0.05f, () -> cfg.freelookSens, v -> cfg.freelookSens = v,
						v -> Math.round(v * 100) + "%"));
				rows.add(Row.toggle("Third person while held", () -> cfg.freelookThird, v -> cfg.freelookThird = v));
			}
			case 8 -> rows.add(Row.toggle("Enabled", () -> cfg.autoSprint, v -> cfg.autoSprint = v));
			case 9 -> {
				rows.add(Row.toggle("Menu click sounds", () -> cfg.soundUi, v -> cfg.soundUi = v));
				rows.add(Row.toggle("Toggle sounds", () -> cfg.soundToggle, v -> cfg.soundToggle = v));
				rows.add(Row.choice("Hit sound", new String[]{"Off", "Click", "Orb"}, () -> cfg.soundHit, i -> cfg.soundHit = i));
			}
			case 10 -> rows.add(Row.toggle("Enabled", () -> cfg.menuBlur, v -> cfg.menuBlur = v));
			case 11 -> rows.add(Row.slider("Glass opacity", 0.2f, 0.9f, 0.05f, () -> cfg.glassAlpha, v -> cfg.glassAlpha = v,
					v -> Math.round(v * 100) + "%"));
			default -> rows.add(Row.slider("Corner radius", 0f, 24f, 1f, () -> cfg.menuRadius, v -> cfg.menuRadius = v,
					v -> Math.round(v) + " px"));
		}
		return new SettingsScreen(parent, name, rows);
	}

	public static SettingsScreen forSkin(Screen parent) {
		CosmeticsConfig cfg = CosmeticsConfig.get();
		List<Row> rows = new ArrayList<>();
		rows.add(Row.button("Open skins folder", () -> {
			try { Util.getOperatingSystem().open(CustomSkin.dir().toFile()); } catch (Exception ignored) {}
		}));
		rows.add(Row.choice("Arms", new String[]{"Classic", "Slim"}, () -> cfg.skinSlim ? 1 : 0, i -> cfg.skinSlim = i == 1));
		return new SettingsScreen(parent, "Skin", rows);
	}
}
