package uz.cosmeticsmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

/** Mod tovushlari (Client Sound moduli). */
public final class SoundFx {
	private SoundFx() {}

	private static boolean ok() {
		return CosmeticsConfig.get().clientSound;
	}

	/** Menyudagi bosish tovushi. */
	public static void click() {
		if (!ok() || !CosmeticsConfig.get().soundUi) return;
		MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.3f));
	}

	/** Modul yoqilganda/o'chirilganda. */
	public static void toggle(boolean on) {
		if (!ok() || !CosmeticsConfig.get().soundToggle) return;
		MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, on ? 1.7f : 0.8f));
	}

	/** Urganda. */
	public static void hit() {
		if (!ok()) return;
		int m = CosmeticsConfig.get().soundHit;
		if (m == 1) MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.9f));
		else if (m == 2) MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.4f));
	}
}
