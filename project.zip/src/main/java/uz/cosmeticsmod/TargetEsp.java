package uz.cosmeticsmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/** Target ESP: nishon atrofida pulsatsiyalanuvchi halqa va shaffof quti. */
public final class TargetEsp {
	private static final Identifier RING = Identifier.of(CosmeticsMod.MOD_ID, "textures/fx/ring.png");
	private static final Identifier SOLID = Identifier.of(CosmeticsMod.MOD_ID, "textures/fx/solid.png");
	private static final int LIGHT = 15728880;

	private TargetEsp() {}

	public static void render(WorldRenderContext ctx) {
		CosmeticsConfig cfg = CosmeticsConfig.get();
		if (!cfg.targetEsp) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		MatrixStack matrices = ctx.matrixStack();
		VertexConsumerProvider consumers = ctx.consumers();
		if (matrices == null || consumers == null || mc.world == null) return;
		LivingEntity t = TargetTracker.current(mc);
		if (t == null) return;

		float td = mc.getRenderTickCounter().getTickDelta(false);
		Vec3d cam = ctx.camera().getPos();
		Vec3d pos = t.getLerpedPos(td);
		float cx = (float) (pos.x - cam.x), cy = (float) (pos.y - cam.y), cz = (float) (pos.z - cam.z);
		float hw = t.getWidth() / 2f + 0.05f, hh = t.getHeight() + 0.05f;
		int col = EffectsManager.rgb(cfg.espColor, 0f);
		float pulse = 0.5f + 0.5f * (float) Math.sin((mc.world.getTime() + td) * 0.2);

		matrices.push();
		MatrixStack.Entry e = matrices.peek();

		if (cfg.espStyle != 1) {
			RenderLayer layer = RenderLayer.getEntityTranslucent(RING);
			VertexConsumer vc = consumers.getBuffer(layer);
			float r = (t.getWidth() * 0.9f + 0.35f) * (1f + 0.12f * pulse);
			float y = cy + 0.03f;
			vert(vc, e, cx - r, y, cz - r, 0, 0, col, 0.95f);
			vert(vc, e, cx - r, y, cz + r, 0, 1, col, 0.95f);
			vert(vc, e, cx + r, y, cz + r, 1, 1, col, 0.95f);
			vert(vc, e, cx + r, y, cz - r, 1, 0, col, 0.95f);
			if (consumers instanceof VertexConsumerProvider.Immediate imm) imm.draw(layer);
		}
		if (cfg.espStyle != 0) {
			RenderLayer layer = RenderLayer.getEntityTranslucent(SOLID);
			VertexConsumer vc = consumers.getBuffer(layer);
			float a = 0.16f + 0.1f * pulse;
			float x0 = cx - hw, x1 = cx + hw, z0 = cz - hw, z1 = cz + hw, y0 = cy, y1 = cy + hh;
			// 4 yon devor + tepa
			face(vc, e, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, col, a);
			face(vc, e, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, col, a);
			face(vc, e, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, col, a);
			face(vc, e, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, col, a);
			face(vc, e, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, col, a);
			if (consumers instanceof VertexConsumerProvider.Immediate imm) imm.draw(layer);
		}
		matrices.pop();
	}

	private static void vert(VertexConsumer vc, MatrixStack.Entry e, float x, float y, float z, float u, float v, int rgb, float a) {
		vc.vertex(e, x, y, z)
				.color((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, Math.max(0, Math.min(255, (int) (a * 255))))
				.texture(u, v)
				.overlay(OverlayTexture.DEFAULT_UV)
				.light(LIGHT)
				.normal(e, 0f, 1f, 0f);
	}

	private static void face(VertexConsumer vc, MatrixStack.Entry e,
							 float ax, float ay, float az, float bx, float by, float bz,
							 float cx, float cy, float cz, float dx, float dy, float dz, int rgb, float a) {
		vert(vc, e, ax, ay, az, 0.5f, 0.5f, rgb, a);
		vert(vc, e, bx, by, bz, 0.5f, 0.5f, rgb, a);
		vert(vc, e, cx, cy, cz, 0.5f, 0.5f, rgb, a);
		vert(vc, e, dx, dy, dz, 0.5f, 0.5f, rgb, a);
	}
}
