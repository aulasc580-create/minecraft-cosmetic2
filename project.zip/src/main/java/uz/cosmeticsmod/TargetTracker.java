package uz.cosmeticsmod;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;

/** Nishon: oxirgi urilgan yoki nishon nuqtasidagi jonzot (Target HUD / Target ESP uchun). */
public final class TargetTracker {
	private static LivingEntity attacked;
	private static int attackedTick;
	private static int tick;

	private TargetTracker() {}

	public static void init() {
		AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
			if (world.isClient() && entity instanceof LivingEntity le) {
				attacked = le;
				attackedTick = tick;
				SoundFx.hit();
			}
			return ActionResult.PASS;
		});
	}

	public static void tick(MinecraftClient mc) {
		tick++;
	}

	public static LivingEntity current(MinecraftClient mc) {
		if (mc.player == null) return null;
		Entity t = mc.targetedEntity;
		if (t instanceof LivingEntity le && le != mc.player) return le;
		if (attacked != null && tick - attackedTick < 80 && attacked.isAlive() && !attacked.isRemoved()
				&& attacked.distanceTo(mc.player) < 40f) {
			return attacked;
		}
		return null;
	}
}
