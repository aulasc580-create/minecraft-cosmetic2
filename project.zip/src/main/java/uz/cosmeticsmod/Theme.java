package uz.cosmeticsmod;

/** Menyu rang mavzulari. */
public final class Theme {
	public final String id, name;
	public final int border, panel, side, card, cardHover, accent, accentSoft, muted;

	private Theme(String id, String name, int border, int panel, int side, int card, int cardHover,
				  int accent, int accentSoft, int muted) {
		this.id = id; this.name = name; this.border = border; this.panel = panel; this.side = side;
		this.card = card; this.cardHover = cardHover; this.accent = accent; this.accentSoft = accentSoft;
		this.muted = muted;
	}

	public static final Theme[] ALL = {
			new Theme("violet", "Neon Violet", 0xFF2E2250, 0xF2110C1E, 0xFF0C0816, 0xFF1A1330, 0xFF261B48,
					0xFFA855F7, 0xFF3A2468, 0xFF8F86AD),
			new Theme("pink", "Pink", 0xFF4A2038, 0xF2200E18, 0xFF160A11, 0xFF2E1423, 0xFF40192F,
					0xFFEC4899, 0xFF5A2342, 0xFFB38AA0),
			new Theme("blue", "Dark Blue", 0xFF1C2E52, 0xF20A1022, 0xFF060A16, 0xFF111A33, 0xFF182548,
					0xFF3B82F6, 0xFF1B3366, 0xFF8196BD)
	};

	public static Theme current() {
		String id = CosmeticsConfig.get().theme;
		for (Theme t : ALL) if (t.id.equals(id)) return t;
		return ALL[0];
	}
}
