package uz.cosmeticsmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/** Yuqori o'rtadagi "orolcha" (watermark): nik, ping, FPS, vaqt. */
public final class WatermarkHud {
	private WatermarkHud() {}

	public static final String[] RATIO_NAMES = {"4:3", "5:4", "3:2", "16:10", "1:1"};
	public static final float[] RATIOS = {4f / 3f, 5f / 4f, 3f / 2f, 16f / 10f, 1f};

	public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
		CosmeticsConfig cfg = CosmeticsConfig.get();
		if (!cfg.watermark) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden) return;

		List<String> parts = new ArrayList<>();
		if (cfg.wmName) parts.add(mc.player.getName().getString());
		if (cfg.wmPing) {
			int ping = 0;
			if (mc.getNetworkHandler() != null) {
				PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
				if (e != null) ping = e.getLatency();
			}
			parts.add(ping + " ms");
		}
		if (cfg.wmFps) parts.add(mc.getCurrentFps() + " FPS");
		if (cfg.wmTime) {
			LocalTime t = LocalTime.now();
			parts.add(String.format("%02d:%02d", t.getHour(), t.getMinute()));
		}
		if (parts.isEmpty()) parts.add("Rediska4");

		Theme th = Theme.current();
		int accent = th.accent;
		int h = 20, iconW = 10, sepW = 11;
		int textW = 0;
		for (String p : parts) textW += mc.textRenderer.getWidth(p);
		int w = iconW + textW + sepW * (parts.size() - 1) + 10;
		int x = (mc.getWindow().getScaledWidth() - w) / 2;
		int y = 6;

		// Orolcha: yumaloq qora kapsula + ingichka rangli chegara
		capsule(ctx, x - 1, y - 1, w + 2, h + 2, (accent & 0xFFFFFF) | 0x66000000);
		capsule(ctx, x, y, w, h, 0xE60A0A10);
		// (bu yerga keyinchalik logo qo'yiladi)

		int cx = x + iconW;
		int ty = y + 6;
		for (int i = 0; i < parts.size(); i++) {
			if (i > 0) {
				ctx.fill(cx + 5, y + 6, cx + 6, y + h - 6, 0x55FFFFFF);
				cx += sepW;
			}
			ctx.drawTextWithShadow(mc.textRenderer, parts.get(i), cx, ty, i == 0 && cfg.wmName ? 0xFFFFFFFF : 0xFFE6E6F0);
			cx += mc.textRenderer.getWidth(parts.get(i));
		}
	}

	private static void capsule(DrawContext ctx, int x, int y, int w, int h, int color) {
		int r = h / 2;
		ctx.fill(x + r, y, x + w - r, y + h, color);
		for (int i = 0; i < r; i++) {
			// yarim doira: har bir ustun uchun balandlik
			double dx = r - i - 0.5;
			int half = (int) Math.round(Math.sqrt(Math.max(0, r * r - dx * dx)));
			ctx.fill(x + i, y + r - half, x + i + 1, y + r + half, color);
			ctx.fill(x + w - i - 1, y + r - half, x + w - i, y + r + half, color);
		}
	}
}
