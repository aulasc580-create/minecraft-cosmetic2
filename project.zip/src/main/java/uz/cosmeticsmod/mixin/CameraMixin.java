package uz.cosmeticsmod.mixin;

import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.cosmeticsmod.FreelookManager;

/** Freelook: kamera burchagini o'zimizniki bilan almashtiradi. */
@Mixin(Camera.class)
public abstract class CameraMixin {
	@Shadow
	protected abstract void setRotation(float yaw, float pitch);

	@Inject(method = "update", at = @At("TAIL"), require = 0)
	private void cosmetics$freelookCamera(CallbackInfo ci) {
		if (FreelookManager.active) {
			this.setRotation(FreelookManager.yaw, FreelookManager.pitch);
		}
	}
}
