package uz.cosmeticsmod.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.cosmeticsmod.FreelookManager;

/** Freelook: sichqoncha harakati o'yinchini emas, faqat kamerani aylantiradi. */
@Mixin(Entity.class)
public abstract class EntityLookMixin {
	@Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
	private void cosmetics$freelook(double dx, double dy, CallbackInfo ci) {
		if (FreelookManager.active && (Object) this == MinecraftClient.getInstance().player) {
			FreelookManager.turn(dx, dy);
			ci.cancel();
		}
	}
}
