package uz.cosmeticsmod.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.cosmeticsmod.CosmeticsConfig;
import uz.cosmeticsmod.WatermarkHud;

/** Cho'zilgan ekran: 3D dunyo proyeksiyasining aspect ratio'sini o'zgartiradi (menyu/HUD ta'sirlanmaydi). */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
	@Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true, require = 0)
	private void cosmetics$aspect(CallbackInfoReturnable<Matrix4f> cir) {
		CosmeticsConfig cfg = CosmeticsConfig.get();
		if (!cfg.aspectRatio) return;
		var window = MinecraftClient.getInstance().getWindow();
		float actual = (float) window.getFramebufferWidth() / (float) window.getFramebufferHeight();
		int i = Math.max(0, Math.min(WatermarkHud.RATIOS.length - 1, cfg.aspectIndex));
		float target = WatermarkHud.RATIOS[i];
		cir.setReturnValue(new Matrix4f().scaling(actual / target, 1f, 1f).mul(cir.getReturnValue()));
	}
}
