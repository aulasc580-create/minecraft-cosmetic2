package uz.cosmeticsmod.mixin;

import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import uz.cosmeticsmod.CosmeticsConfig;

/** Viewmodel: birinchi shaxsdagi qo'l/item joylashuvi va kattaligi. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
	@ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, require = 0)
	private MatrixStack cosmetics$viewmodel(MatrixStack matrices) {
		CosmeticsConfig c = CosmeticsConfig.get();
		if (c.viewmodel) {
			matrices.translate(c.vmX, c.vmY, c.vmZ);
			matrices.scale(c.vmScale, c.vmScale, c.vmScale);
		}
		return matrices;
	}
}
