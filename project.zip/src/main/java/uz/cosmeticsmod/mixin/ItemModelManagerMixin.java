package uz.cosmeticsmod.mixin;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import uz.cosmeticsmod.Cosmetic;
import uz.cosmeticsmod.CosmeticSlot;
import uz.cosmeticsmod.CosmeticsConfig;

/**
 * Mace skin: item modeli tanlanayotganda mace'ni Mjolnir modeli bilan almashtiradi.
 * (Faqat chizish uchun nusxa ishlatiladi, haqiqiy item o'zgarmaydi.)
 */
@Mixin(targets = "net.minecraft.client.render.item.ItemModelManager")
public abstract class ItemModelManagerMixin {
	@ModifyVariable(method = "update", at = @At("HEAD"), argsOnly = true, require = 0)
	private ItemStack cosmetics$maceSkin(ItemStack stack) {
		if (stack == null || !stack.isOf(Items.MACE)) return stack;
		Cosmetic skin = CosmeticsConfig.get().equippedIn(CosmeticSlot.MACE);
		if (skin == null || skin.itemModel == null) return stack;
		ItemStack copy = stack.copy();
		copy.set(DataComponentTypes.ITEM_MODEL, skin.itemModel);
		return copy;
	}
}
