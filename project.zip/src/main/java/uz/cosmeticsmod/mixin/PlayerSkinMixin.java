package uz.cosmeticsmod.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.cosmeticsmod.CosmeticsConfig;
import uz.cosmeticsmod.CustomSkin;

/** O'zingiz yuklagan skinni FAQAT o'zingizning o'yinchingizga qo'yadi. */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class PlayerSkinMixin {
	@Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true, require = 0)
	private void cosmetics$customSkin(CallbackInfoReturnable<SkinTextures> cir) {
		if ((Object) this != MinecraftClient.getInstance().player) return;
		Identifier id = CustomSkin.textureOrNull();
		if (id == null) return;
		SkinTextures o = cir.getReturnValue();
		SkinTextures.Model m = CosmeticsConfig.get().skinSlim ? SkinTextures.Model.SLIM : SkinTextures.Model.WIDE;
		cir.setReturnValue(new SkinTextures(id, o.textureUrl(), o.capeTexture(), o.elytraTexture(), m, o.secure()));
	}
}
