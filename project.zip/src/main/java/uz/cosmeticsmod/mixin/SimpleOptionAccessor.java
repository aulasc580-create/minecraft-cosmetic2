package uz.cosmeticsmod.mixin;

import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Fullbright uchun: gamma qiymatini tekshiruvsiz yozish. */
@Mixin(SimpleOption.class)
public interface SimpleOptionAccessor<T> {
	@Accessor("value")
	void cosmetics$setValue(T value);
}
